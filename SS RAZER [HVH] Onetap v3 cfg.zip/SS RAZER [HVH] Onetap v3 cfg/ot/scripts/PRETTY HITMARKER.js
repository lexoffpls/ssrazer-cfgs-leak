UI.AddSubTab(["Visuals", "SUBTAB_MGR"], "HitmarkerTab");
UI.AddColorPicker(["Visuals", "HitmarkerTab", "HitmarkerTab"], "Color");
var iVictim_index, First_pos, Other_pos, First, Other2, Other3, Other4, Other5, iDamageCount = iOffsetCount = YOffsetFirst = YOffsetSecond = YOffsetThird = YOffsetFourth = YOffsetFive = loadFont = HitAttack = 0;
const first_screen_pos = [], second_screen_pos = [], third_screen_pos = [], fourth_screen_pos = [], fifth_screen_pos = [];
function EVENT_PLAYER_HURT()
{
    iAttacker = Event.GetInt("attacker"); iAttacker_index = Entity.GetEntityFromUserID(iAttacker);
    iVictim = Event.GetInt("userid"); iVictim_index = Entity.GetEntityFromUserID(iVictim);
    if(Entity.GetLocalPlayer() == iVictim_index && Entity.GetLocalPlayer() !== iAttacker_index)    return;
    if(Entity.GetLocalPlayer() == iAttacker_index)
    {
        HitAttack = 1;
   
        if(iDamageCount == 5) iDamageCount = 0; if(iOffsetCount == 5) iOffsetCount = 0;
   
        iDamageCount+=1;
   
        iOffsetCount+=1;
    Other = Event.GetInt("dmg_health");
    Other2 = Event.GetInt("dmg_health");
    Other3 = Event.GetInt("dmg_health");
    Other4 = Event.GetInt("dmg_health");
    Other5 = Event.GetInt("dmg_health");
    Other_pos = Entity.GetRenderOrigin(iVictim_index);    
        if(iDamageCount == 1)    {    First = Event.GetInt("dmg_health");    First_pos = Entity.GetRenderOrigin(iVictim_index);    }

       //Setup offsets
        if(iOffsetCount == 1)    YOffsetFirst = 255; if(iOffsetCount == 2)    YOffsetSecond = 255; if(iOffsetCount == 3)    YOffsetThird = 255; if(iOffsetCount == 4)    YOffsetFourth = 255; if(iOffsetCount == 5)    YOffsetFive = 200;          
    }  
}

function HUD_REDRAW2()
{
    if(loadFont == 0)
    {
        fontSM2 = Render.AddFont("Lucon.ttf", 12, 590)
        loadFont = 1;
    }
    if(!HitAttack) return;
    if(Entity.IsValid(iVictim_index))
    {
     

        if(iDamageCount < 6)
        {
            first_screen_pos = Render.WorldToScreen(First_pos);
            second_screen_pos = Render.WorldToScreen(Other_pos);
            third_screen_pos = Render.WorldToScreen(Other_pos);
            fourth_screen_pos = Render.WorldToScreen(Other_pos);
            fifth_screen_pos = Render.WorldToScreen(Other_pos);
        }
     
        color = UI.GetColor(["Visuals", "HitmarkerTab", "HitmarkerTab", "Color"]);
            Render.String(first_screen_pos[0]-15+1, first_screen_pos[1]-50+YOffsetFirst-255+1, 1, "" + First, [ 0, 0,0, YOffsetFirst ], fontSM2);
            Render.String(first_screen_pos[0]-15, first_screen_pos[1]-50+YOffsetFirst-255, 1, "" + First, alp( color, YOffsetFirst ), fontSM2);
     
            Render.String(second_screen_pos[0]+15+1, second_screen_pos [1]-50+YOffsetSecond-255+1, 1, "" + Other2, [ 0, 0, 0, YOffsetSecond ], fontSM2);
            Render.String(second_screen_pos[0]+15, second_screen_pos [1]-50+YOffsetSecond-255, 1, "" + Other2, alp( color, YOffsetSecond ), fontSM2);
     
            Render.String(third_screen_pos[0]-25+1, third_screen_pos[1]-50+YOffsetThird-255+1, 1, "" + Other3, [ 0,0,0, YOffsetThird ], fontSM2);
            Render.String(third_screen_pos[0]-25, third_screen_pos[1]-50+YOffsetThird-255, 1, "" + Other3, alp( color, YOffsetThird ), fontSM2);
     
            Render.String(fourth_screen_pos[0]+25+1, fourth_screen_pos[1]-50+YOffsetFourth-255+1, 1, "" + Other4, [ 0, 0, 0, YOffsetFourth ], fontSM2);
            Render.String(fourth_screen_pos[0]+25, fourth_screen_pos[1]-50+YOffsetFourth-255, 1, "" + Other4, alp(color, YOffsetFourth ), fontSM2);
     
            Render.String(fifth_screen_pos[0]-10+1, fifth_screen_pos[1]-50+YOffsetFive-255+1, 1, "" + Other5, [ 0, 0, 0, YOffsetFive ], fontSM2);
            Render.String(fifth_screen_pos[0]-10, fifth_screen_pos[1]-50+YOffsetFive-255, 1, "" + Other5, alp( color, YOffsetFive ), fontSM2);
     
    }  
}

function getCustomValue(name)
{
    var value = UI.GetValue(["Visuals", "HitmarkerTab", "HitmarkerTab", name]);
}
function pushY()
{
    //Push Y
        if(YOffsetFirst > 1)    YOffsetFirst--; if(YOffsetSecond > 1)    YOffsetSecond--; if(YOffsetThird > 1)    YOffsetThird--; if(YOffsetFourth > 1)    YOffsetFourth--; if(YOffsetFive > 1)    YOffsetFive--;
}

function alp(c, a) {
  return [c[0], c[1], c[2], a]
}
Global.RegisterCallback("Draw", "HUD_REDRAW2");
Global.RegisterCallback("player_hurt", "EVENT_PLAYER_HURT");
Global.RegisterCallback("CreateMove", "pushY");