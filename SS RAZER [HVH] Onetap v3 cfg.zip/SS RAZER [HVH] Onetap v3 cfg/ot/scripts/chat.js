const master_switch = UI.AddCheckbox("premium trashtalk");
const normal_killsays = ["!rs"
];
 
const hs_killsays = ["!rs"
];

const on_player_death = function()
{
    if(UI.GetValue.apply(null, master_switch))
    {
        const attacker = Entity.GetEntityFromUserID(Event.GetInt("attacker"));
        if(Entity.IsLocalPlayer(attacker) && attacker != Entity.GetEntityFromUserID(Event.GetInt("userid")))
        {
            Cheat.ExecuteCommand("say " + (Event.GetInt("headshot") == 1 && Math.random() > 0.5 ? hs_killsays[Math.floor(Math.random() * hs_killsays.length)] : normal_killsays[Math.floor(Math.random() * normal_killsays.length)]));
        }
    }
};

Cheat.Print("trashtalk js loaded, killsay count: " + normal_killsays.length + hs_killsays.length + "\n");
Cheat.RegisterCallback("player_death", "on_player_death");