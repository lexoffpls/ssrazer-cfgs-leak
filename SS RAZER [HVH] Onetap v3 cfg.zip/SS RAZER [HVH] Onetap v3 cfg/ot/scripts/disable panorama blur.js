UI.SetValue( "Misc", "GENERAL", "Misc", "Force sv_cheats", true );
UI.SetValue( "Misc", "GENERAL", "Misc", "Hidden cvars", true );
Global.ExecuteCommand( "@panorama_disable_blur 1" );