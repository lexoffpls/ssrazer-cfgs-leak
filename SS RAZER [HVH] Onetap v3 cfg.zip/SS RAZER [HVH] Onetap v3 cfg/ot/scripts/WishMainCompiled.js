/*



            ░           ░  ░               ░                 ░  ░   ░     
                                                                          
																		  */
																		  
																		  
var _0x491d = ['ECkXW5K+WOzXW6O=', 'lSoHWOWaW5FcO8kajW==', 'EX53W7NdRCoofs3cIW==', 'WP4UWQXGivhcRCoOW7VcOXRcRtu=', 'WO0YWQnOBKtcL8oI', 'g23dJ8khW4CqWRVcI35XWOfsua==', 'n8k1dmkywmkuW7q=', 'W4ZcLLXOW6DPW4pdNa==', 'suu6zq==', 'W4OIWRuGqaycWQFdO8oqWR7dRCog', 'W5RcNKX/', 'WQrHWOeVkq==', 'W57cP1RcGq3cUq==', 'CmoUkvVcPCoXhJNdRG==', 'W4jUzmoNWOpcIajiWO3cJa==', 'vxRdIKKvW4XQWRfxWQLOWPNdIqy=', 'WQX6WOqtmMpcNSoniYRcS8oKxCoW', 'imk/WQ0XW5SrW4lcLmonWQrleG==', 'W5tcQSkVW6BcKCkHWRu7WO1HWPi4', 'h8o5eSkmWONcHrm=', 'imoQWO4ZW4tcU8kqma==', 'hv3dR8kBW7CSWPFcVLvW', 'WRW1FSkLzCoCWPpcLWqU', 'WPNdKmoXz8o2W6v2EmogoW==', 'j8kdtSoqWPdcQuNdH8o7z8kTW4i=', 'mwhdLq==', 'lJdcM8kMW4euWRhcGMzhWPO=', 'nCo9d8kXWRxcLHCbrSkqq8o7WQG=', 'W6SivZyFm08=', 'w8oFBCkwWOWzt3O=', 'WP42ySk3kCosWONcNXi=', 'tmoUdKtcSSoHaWe=', 'W5KpuHDtAbVcKKRcL8kqwW==', 't0uVz8khkeCNCW==', 'F3BdKa==', 'WQ8HW4VcMmoyjZOXW4GxWRLI', 'WOCUW5FdOSoUWRS=', 'Fq53W4dcRmosbs0=', 'WQ9WdfRcRXJcHNJcMKDCW5y=', 'WOG8Cmk8nSodWPJcJceQmmkNuepdTGG=', 'WO4YWQ5Niu/dQa==', 'pSoKB8oUW5dcHG==', 'aSoTcmkk', 'EbWFWQ3dLmkLW6JcKd4T', 'WPmlW4e=', 'agjLWOb/W7qVxHldOCkQWOms', 'tbdcM0xcUCkeW6qVWP3cSa==', 'W7NcPqldGgVdO8oFAZSupSkSmmob', 'W58UEafTqdm=', 'WRmhCq==', 'fCk6W4eXEuFcQmo3WOBdKmkUW4upW74zlhS=', 'jSo9a8kwWOxcJqGb', 'wmoaWQfLCmo3ga==', 'W5lcJ09WW6f2W5ldSG==', 'draWWQWrW7NcIq==', 'W4JcLc/dUMK=', 'WOG0WRHIzq==', 'zrqqWRxdMmk3W5/cQa==', 'zXdcMq==', 'D8okWQfxA8o2dmkE', 'WPddIaPVyJZdNmkwW74pdmox', 'cg3dG8kGW7ClWQtcI1nxWPTCwSoC', 'kmkQWRWSW5WaW6tcVa==', 'etqDWP0QW47cOce=', 'WRKhW5S4WR9qxcyMWOLqtH7cTJu=', 'w8ooA8k8WO0s', 'w8osWOVcGSkr', 'WPhcR8oHW5K=', 'WPm1WQLPExZcRG==', 'WQ4+WRv4uLRcSSo/W53cOH3cUcKL', 'WR9tg1lcSrdcQ1NcIebwW4K=', 'W5dcKKTFW6fZW4NdSW==', 'odBdMa==', 'WR13W7e=', 'u8k1W4qaWQT6W64=', 'nmkUWQSlW5yeW6tcHmoqWOnnbCkA', 'WOKlW4epWRvvDtO=', 'w8oXW4zRWPpdGCoYWQ0rrmkGumoA', 'W68cwcbqDIdcJW==', 'nCo9d8kKWRFcJXC9sCk0', 'z8osW57dOqi0xmo1vConWQhdKq==', 'WPCWzmk2', 'W7RcNLe=', 'WQaDCCoH', 'gdazWOaWW4ZcOa7cGdVdO8oqnuO7cW==', 'smo1W4bFWPxdH8o+WQyy', 'WPBcJSofWOC=', 'imoQWO41W4NcTSkCmmklW6G=', 'WQ4nWPfRW7CE', 'W65ar8klfCkCxJ8PWQNcGG==', 'C8otWO/cJCkxW4TpBXmA', 'WQK6WQTPiupcP8oZW7dcO07cOZaTWOa9iqv2', 'WP3cImoeWODZWO0HWQy4W60kwhieW4JdPa==', 'cmk+gSkzqCk1W7m=', 'e8oQWPLfWPW=', 'abqOWQGqW7VcLZxcKW4=', 'dSo9dqBdVSkIWQFcPSoUA0FdKa==', 'WR4qW7tdVYeGW7q9iCov', 'bMLLWROXW4CJvG==', 'WPKjWPX4W6Oaz8kl', 'w8ooA8k8WO0sy31cW6xcN8oz', 'WP3cJSoAWOHZW4KaWQi9W7W=', 'WPiZW4NdP8oLWRJdLmklrfO=', 'm8kXgCkz', 'W6tcRGZdKuRdVSoaFa==', 'D8ozWPBcSSkvWODPAW==', 'FNRdKgioW4C=', 'WRCDW7tdMwK2W785n8ojcW==', 'W4aIW75OAWtcJZeH', 'ux7dKMWyW51I', 'WROpo8oBgCozxX0UWR/cK8oAzSoQ', 'W5aeqI9AEaZcQea=', 'dSo/gqRcRSkMW6JcPSo0EGRdJfldMmkoWOnHWRSX', 'FSoOmvZcPCoSpWpdTCke', 'W5KIWRKhCb0DWQFdJSo2WQtdO8omAG==', 'hdZdNWuCBHWWEmoComooWQu=', 'cCoGWPCeW4hdT8koo8kqW70s', 'WR07W43cMmoxkrqBW4i=', 'WReaWP5OW6WbiSkYW4ldJCkDWP7cVXm=', 'kSkaW44xAedcQmo3WRpdLmkWW70mW60DiG==', 'WPBdIrPVBsFdNCkwW6ivc8ozFa==', 'umk/W4uYWRvWWR7dIMRcQq==', 'W7KEuq==', 'r8ovW4VcQfXR', 'qCoWxSoCgCoAWRv3W5ddVWRcULGFWRJcS1KxWQJcUf0iW6ddMSk7hcjLW6pcN35gW6VdV8kEtqBdPW==', 'W5KEqISFCrRcKLm=', 'W4dcQrq=', 'vg3dN2GFW5TIWRbI', 'W51kzSk1bmkusq==', 'vmorfmoeW5RcLeG=', 'WO/cP8oOW5K=', 'W4pcU8k1W6/cHSkHW6eXW4XTWPa0WRxcPG==', 'WOqnESo9WO8ZxfJdH1HObCkZWR4=', 'WP06WQfLBrpcQCoO', 'wrRcHudcRmkuWPyJWORcOCoEW5i=', 'WQuAW6ldS3eNWRW7iCodhSkx', 'lmkaW5eksf3cT8oGWRpdGmkVW6ubW6e=', 'jYzEWPvJ', 'WReCW6tdIwiHW7K3o8o1gSkEcq==', 'BCkDW7vhz8oUb8kbW57dI8o9', 'Fq53W5xcPCoFaI/cHq==', 'WQiqW7pdSwmYW683cSoF', 'mCkpsmolWP8=', 'WPybBSoLWRK+DfJdP1K=', 'W7FcQSkOW5xcGSk5W6a7', 'WRKhW5SLWRTptW==', 'jSk1cSkQwmkwW6aY', 'W7VdH8kwW4q2WO1YW6D+WQGkcd1nWOBcSmkwxJ9reSocWO7cPCk/cCkXhXvUWPuFEsNdS25bWOS=', 'uCoxe8om', 'hSkuWRyiW5WyW6y=', 'WPxdUmolsSoaW4j2vmo1gW==', 'WQCQW4NdOSoJWRK=', 'WQGWW4hcHCoLkqmHW7GwWQv7W5NcNG==', 'WOeQWP5/W6yMBSk3W5RdJ8ki', 'WQ0bW50cWQPwcIOGWR9jtW==', 'WPqwW6FdS2rZW7C8pmoafG==', 'BmkTWOi=', 'W4C3W75MybFcPsO1ibZcKG==', 'urJcLf3cTCkwW5mx', 'qmk1W4GKWOP8W6tdM0JcRcVdO8oYWRS=', 'WOqbWPnGW6ysumkZW4ddNG==', 'DaPNW7/cO8oAgq==', 'WOLSWQiBmMa=', 'WQnMWR4FiYJcImovbcZdP8o9rmo8W6ldSa==', 'WRyuW6/cSmoLaYSnW6S3', 'WPZdHbu=', 'WRmlW5Wi', 'ewhdImk3', 'w8oUlG==', 'WPZcGSocWQj3W4y3WP4/W78=', 'WReuWQXRzq==', 'nmkXWPqkW6i=', 'WQ9iWPO9fuVcQCo9mH0=', 'WPeyWPPVW7CxDSk5W5hdMq==', 'D8ozWPBcTmkgWOrS', 'WRJdH2qZWRRcLd/cPWSnW4BdPmkwWQe=', 'B8kxW6af', 'AHalWRxdOSkOW4dcKb4SdwJdNhO=', 'uYOBWO7dK8kYW5/cHYS8deJdKMv8WPBdVW==', 'W4dcNXldU1RdUCoaFa4ep8kmpSoEv8kaWRa=', 'bSo/hbVdP8kGW6lcKG==', 'WQrNWRGvj2hcLSoRgW==', 'C8odW5JdIWm/CmoY', 'nCoUWP0a', 'WOtcQ8oYW67cGSkjeuJdOvG=', 'CmojW5NdQGa2p8o0r8oj', 'WOCUW5FdOSoUWRVdHCkBvfRdSre=', 'W51kzSkTbmkvwrK=', 'fmoOBCoLW4hcISoummoBWPa=', 'v8okWQfEz8oHgW==', 'iCoOhSkbW7BcIbSxxa==', 'WOP9rxtcNW==', 'WPFcP8oLW5FcLCkjcxq=', 'm8kssmo6WPhcOMxdGa==', 'W7RcLLzYW5f3W4NdTs50s1q=', 'WQjSWRGVjxRcNSordbRcRSo3tG==', 'WRmbW6ddTM46W6GH', 'wCokWQDwz8k4cSkcW4ZdL8kVWPpdJLe=', 'WR5gwxNcS8koWRSj', 'm25aWR9E', 'x8owW5nlWPxdO8o7WQKgCSk7', 'k8kHW6pcRJj+WPTp', 'W6JcUa7dHLK=', 'WP08y8kgjSofWPJcMWWynCkXvW==', 'oIanWOe=', 'W5JcVmkPW5hcTa==', 'zNddQ3ukW4P5WP5MWRzS', 'sar2W7JcQq==', 'trZcG3NcRSkpW4y=', 'W7FcQSkOW5dcHSkNW6m7WP5vWOOVWRRcRtq=', 'W5pcHv5R', 'sWCaWRtdGSoHW5hcMZq/gW==', 'sH5WW74=', 'WRz5WQKFmMNcJ8oBedO=', 'p8kaW50TEeBcQmoGWP7dPSk1W6Sl', 'WROxW4WaW7PstYy/W7PftWtcSshdIq==', 'W7uHW78=', 'WPZcGSocWRfLW4GGWQK/W6vp', 'wmoaWQfMyCoQdCkiW4BdVCoMWOJdGG==', 'W4SMWQOwaXujWQxdOCoMWQq=', 'W5RcMeL5W6n6W4JdTq==', 't8oBfmo5W57cGu5F', 'nmo7WOGmW4VcSmkMimkkW68yWOS=', 'mCkptmovWPhcP37dGq==', 'Aq53W5xcOSoshZO=', 'W73cPSkVW6a=', 'W4SUWQ0FrHa1WQFdRSo3', 'WOfSWR8znhZdM8oraY7cQ8oO', 'W7FcQSkOW4/cJmk2W7qYWRXQWP8KWRBcSq==', 'wSoFc8okWP/cIu5zWQi=', 'WQ0yW7pdRMGLW7Kp', 'WOxdJrXBAYhdKCkDW6S=', 'A8owEmkMWPaCqYHAW7/cMCosDG==', 'eh3dMmk9W4adW77cRx9mWPThwCou', 'WRG/W4VdRmo0WRq=', 'WQpdPmoutG==', 'W4zdqmoeWR/cRZ9R', 'WRXBr3dcRSkgWQm=', 'm2z9WRXYWQyHvrxdLmkM', 'WPmRnG==', 't8oGW4brWP7dLmouWR0my8kMrW==', 'f8oUWOGeW4BcUmkxmCozW7azWO/dO8oj', 'sfq4y8ocmeC6ya==', 'W54IWRuWtbGiWRa=', 'r8kKW4i5WRDYW53dI3JcRtFdUG==', 'hmo6gYNdOCk4W7m=', 'kSkeW44B', 'rCotD8k8WO4atsHvW7dcNCovDeO=', 'imoQWO4WW5BcSSkxo8kyW7ys', 'wmoMW5np', 'WQ/cImoWWO1UW4G2', 'WPFcQ8o+W4JcTmkbb3q=', 'e8oLzCopW4VcGmoY', 'wbZcKedcR8kuW5m4WR3cPCoFW41CW57cUSks', 'W5tcSvn9W713W4tdOcT2', 'fgFdJ8k/W4eBWQ3cSwK=', 'u8k1W4qgWRH5W6VdMW==', 'qwVdJgWuW4HiWQH0WRfMWO0=', 'WOG/uSoqWPy=', 'WRCDW7tdNg49W6G=', 'W45oESkucmky', 'WPS9C8kgkCoEWPNcMXacmSk/', 'fCoXcWtdQ8kVW7q=', 'W4ZcQ1RcGa8=', 'B8ohW4/dVauLESoD', 'iwTWWQb0W6qRvrS=', 'fhnJWRPYW6ejtG/dHSkSWPq=', 'WR1xrxNcUCkdWP0FW7n8', 'sfaVACkmo208z21/kq==', 'g8oYsCoMW5dcHCoJlmo5WOFdVmohv8oA', 'WPm/W5hdHCoHWRhdOW==', 'WQHDw3ZcRmktW68tW6rTlmot', 'w8oBfmo/W5pcJejFWRTs', 'CCoYfv/cTmoJcb/dL8ktWRJcUmkzWRa=', 'jCkQW6hcIc9MWPfp', 'W4LBymksc8kEBWK7WQ7cImoo', 'tmoiEmkI', 'BrybWQJdGCk1WPRcNcK8e28=', 'W4Sirc1pDv/cNKZcU8ktxa==', 'W58oqHDCCXRcKLBcJCkxvte=', 'imoQWPqaW5FcTSkj', 'W69CySoBfG==', 'WOxdM38OWRZcLJtcUq==', 'vxRdILyzW51UWRHPWPzGWPRdIq==', 'lSo8WRikW5hcVmkalmk4W7GdWO/dS8oj', 'j8k5eSkqxmkEW4CYWPpcQW==', 'WR01W4OkWQPnrbahWP0uba==', 'W7/cOr3dKq==', 'WQeaW4/dHmo2', 'k8keW48Bo0tcOSoSWP7dGCo8W74yW6Kmo2zpW78=', 'WPCRW7GSCLC=', 'xCkJW7G/WQ1+W7VdH0RcUIZdVSoRWRm=', 'fmoGASoSWOtcJ8oOmSouWOhdUW==', 'bMxdMSk9W70=', 'WRDgcK/cTGhcJxe=', 'WPSyW7FcUJy=', 'hmoWcWBcO8k3W67cOSk6z0tdLuhdJ8kiWPr6', 'iSo0CSoH', 'nhVdJSkgW7m=', 'WR0BiSo1W7W=', 'WPNdGXPxAYZdIW==', 'fxVdS8k7W5ajWRVcL1fbWPXbq8ou', 'imkwtSoEWPVcUMpdNmoV', 'W5hcLaX8WOJcVHhcM2Pg', 'W51kzSkUfSkCxHiPWRFcGG==', 'W6OYWRvtsbOoWQtdQa==', 'WP7dUmourq==', 'zmozWPRcKmkNWOjMAZ4CW6K9W5BcVq==', 'WRGhDSoRWRu0qK4=', 'WQW+WR9Oyf3cQq==', 'W5blvColWQtcPZ93WRRcRq==', 'jCk1W6FcHbC=', 'wCosWOBcGCkmWQr6', 'bSoKECo9W7FcH8o8mmo7WPhdU8oAtSos', 'WQfDW6WNmdRdLCkaqJVcOSoHtSo0W7/dOCkbwe7dVdidW77cHSodmqS+W7BdJf3cR8oaWOu=', 'WOmmWPTFW68FzSkZW5hdO8kuWO8=', 'k8krkmk9ASk5W4CEWQdcIW==', 'WOmkB8kZcW==', 'WOWnW5OfWR4=', 'W6FcGsZdTwVdICo3rYG1', 'WRCmW6tdTseJW7K3pG==', 'DHa8na==', 'F8oKkwdcSSoNhq==', 'WRXBxuBcV8kvWQOFW75BkmoAga==', 'WR8mW5ScWRTlrXWS', 'W74cqceFCHRcGv3cSa==', 'W5tcJSk4W7lcIG==', 'WP/cLCoxWPm=', 'jCkIh8kl', 'W4OIWRuLqHGsWQC=', 'WPJcTmoBWOT9W4GvWRu7W6zlthG=', 'sWeCWRNdHa==', 'WPeCWO1LW60rqCkJW5ddNSkvWPy=', 'W5KfqI0sqbBcMG==', 'g3ldSmkgW7m=', 'WO1MWRGEl2BcN8oh', 'k8krW5SxDvpcJSoWWOpdGCkZW7W=', 'hSo9fCkfWQlcJa==', 'WOK4CCkWzCohWPlcLWW/FmkKreFdPXfkFgW=', 'adJdIciwAHWi', 'WRGxfIbABr7cJGldVG==', 'WOldJXXvFIhcMmkAW7GJd8oq', 'wSoBFSkW', 'EIftWPRdH8oZWPtdGx0Rg3ddLNzOWPBdLKnzfCoXCSkPWPqPW4G6lXmJyCoojSoo', 'W7r6WOxcQ8ogWP3dJCkRbWy=', 'ErahWPFdKmkTW4/cKa==', 'W4bRxmojWQNcOZLkWQ3cRCkiWPCkAsy=', 'm8kssmoQWP3cVg/dL8oMqmkRW5xdOW==', 'qxZdJgWkW5SRWRrZWQbKWPm=', 'd0jqWOvfWQyACI/dPSkmWRu=', 'W50WW4rGEHVcGYyhnWFcLSkqDq==', 'W7nbDSkEhCk2sG==', 'lCooWQWKW7BcLmk3hmkPW48=', 'W58oqHDACWNcKKRcJCkkxt3cLSoT', 'lmoZcJRdHa==', 'W5BcMuT1WQnEW4/dRa==', 'W4jvrmobW73cHYj1', 'gCkhW5O=', 'WQldHWTqAYhdL8kDWQWTdmokFWa=', 'W4CZW6LSEHhcKJa0jW==', 'DCocW4JdIWm/CmoYDSoqWQ3dL8oDpG==', 'j8kIWRWZW5CxW7lcHmoHWQK=', 'AqDSW6hdRCojestcIW==', 'WPCnDSokWRq7vfRdOq==', 'W7BcOrNdGfhdVmoauW==', 'W51kzSkObSklsrKMWONcJSozoq==', 'WPeIW5hdUCoH', 'hwZdN8kxW4SoWRhcNeblWOTdumod', 'FmovsSkHWPeCtM8=', 'W6PFmSkzdmkdqXi=', 'cM5IWRa=', 'W6PvvmonWQJcIs0=', 'y8o/W6FdMZu=', 'W4pcKKDOW512W5ZdPazKqvmFWOO=', 'g8o3eWpdQ8kYW5xcQSo5EG==', 'BGPXW7hcQmokgsBcHW==', 'nCk1bSkiASktW68YWRpcQLNdRHDs', 'WPayqCkufSo0WQ/cTZiF', 'WQbXWRWqkwhcJ8oh', 'mJFdJZmhuX8=', 'W7BcPSkWW6/cHSkXW4C7WO9Y', 'd251WRy8W7uIvaJdGq==', 'BmoKjutcK8oHfWpdLCkfWR/cPCkaWRG=', 'W7RcJSkkW4lcSmkwW4CxWRXs', 'WRSqW6pdUq==', 'xeePu8kblKSSEKP5pSkY', 'qKNdQ0Oa', 'kJ4XWRf9W78LvrNdHG==', 'nmkUWQSiW4CzW7e=', 'W5KpuGjqBWS=', 'vCkZAqK=', 'WQ0wW50cWRrfAtyNWQ5luq==', 'cc3dMt8rEZOGzCo7pSoz', 'F8oKkwpcO8o6capdUmkJWQxcQ8kk', 'k8kHW6pcOtjXWPvrWPaXWOP/jx0=', 'pSkLW7dcIa==', 'd3ZdICk9W4OfWP3cM2nwWODf', 'WPKBsSoMWQGXq0tdHu5VgmkQWRy=', 'WOJdSmoeuSomW5bbBa==', 'WOPgbvJcTX7cH0ldM19xW408dW==', 'f8oFks7dNCkvW5xcHSokwG==', 'pSkIWQW7', 'jSo9a8kwWOxcJqGbA8k2wCo1WQldJq==', 'q8kXW4q1WQT4W7/dJga=', 'WQ1GWQGzzNVcK8oBfJO=', 'EmorW6rPWQu=', 'g8k7ECoYWRm=', 'wWvmW67cTq==', 'W5JcUSkYW7FcKmk4W7qWW4XTWPa0WRxcPG==', 'FajVW7RcQmoAiI3cGWG=', 'WPKhW5S4WR9brs0WWQK=', 'f8k9W4PvWPu=', 'WQRdLu8OWQFcIt/cGW==', 'dZZdKYiSDqmWvCo6iSoaWQ/dJq==', 'WQfCW59PW7SgBSk5W5ddG8kmWP4=', 'WQTchw7cRblcMKlcMLLC', 'WRayW7VdVYe3W6KXpG==', 'sWZcG0BdVmkqW5mVWPu=', 'dSoYebJcRSkHW6BcO8oX', 'WPRdOSoVsCorW41bsmoxda7cQSoGvW==', 'D8ozWPBcT8kxWPL5AXm6W7mZW5W=', 'WP0bBmoGWReVsX3dOeX2emk7WRy=', 'WPdcRCo0W5xcL8kCxxJdTePVmW==', 'vK0UyW==', 'W4WPWRuAdJuoWQ8=', 'bSoXgmkjW7BcMfi=', 'W5aSW7LTyHxcKJ42', 'hmo9hmkhWQa=', 'p8kfW7uviSk4smonWOJcJSkVW5lcHXZcG8kEW44RWQ56bHGDW6xdGwDEWPTSWOJcOfldJu3cH0Glm8kLW4Pm', 'WQfMWRKEkM3cJ8oveG==', 'smoBgmoBW6ZcHefFWOPuBZf7Dq==', 'gtymWOaZW4ZdPrxcTZ/dOSop', 'WOq7W60jWP0=', 'WOf4axtcVqtcJv7cJvflW7a7gmo8bCoM', 'WR03zmoLWPi/xKNdLf9Yhmk9WQhcRmkcCCkBW6OJpW==', 'zCotDW==', 'vxRdILmBW4n+WRG=', 'bNjLWRW8W7yVxHC=', 'B8oFBCkDWOWauNS=', 'WRzLWQmlzN/cMSoycq==', 'mSkKdmkvv8kD', 'iCoScCklWRJcGZerw8k3rCoS', 'W4tcG011W6b4W6xdTdzLxuO=', 'aCoXzmoQW5dcJ8oYoSokWPC=', 'gSkLWRS9W405W6C=', 'WQldGf41WQdcMbNcQZKAW53dOa==', 'W4aQW69KFbhcKJO=', 'WQHGWQivk33cLSkubIJcQSoStmoW', 'WQbscLlcUXBdIg/cLfPkW4S2dW==', 'EsbTW7/cQ8oB', 'stVcLLRcUCkWW5ORWOFcOCob', 'oCkkWOKzW6y1W5pcQmoUWOq=', 'vSo/nSoUW6ZcRMLZWPL1', 'W6lcRSk1W63cGCk6W6j+WO5NWOW=', 'W4foCCkpdmkpsse=', 'fSkFWOOwW6q=', 'B8o5W51tWPxcK8oWWROAECkOtSoA', 'igjLWP51W6G/tXNdGq==', 'r8kZW4i5WQLHWR7dL3/cVdxdPa==', 'WRz9WR4vkg/cUmobet3cQmoG', 'fCoKDCokW4JcJ8o1jSo2WOxdPCol', 'WRv9t1VcRW==', 'W4SgWOO2a1W=', 'nCo9d8kSWRFcIrC=', 'WRldSeK/WQhcHH3cRc8aW5pdQCkf', 'FarXW7xcQmkEeIFcHaxdPSkDWRmW', 'eSk5ea==', 'o8k1W4uFyLhcV8oxWPxdHSkZW6qCW68B', 'CSo6WR16ymoRdCkFW57dI8o9WQBdHK7dHmkOW4O=', 'dmk5ea==', 'B8oxdG==', 'gJ3dJXOEFHW5', 'W5TlDSk9cSkxwa==', 'WPq8iSosWQPOcaNcPf9+hCk5WRlcPSkMwmopW7DGiaexWQbYWPSNWRVdL3pcT1VdMmkmAq==', 'mmkdWPOFW4CtW6/cGmoAWRu=', 'cZeAWROVW5hcOrNcSrpdOCoi', 'nCkkW58BDLhcO8oX', 'WRmOWOvJDvJcRCoJW5/cTbRcPtaT', 'W4LFD8kyeCkywbm6WQK=', 'trZcG3RcV8ksW5mVWPdcL8oAW5TB', 'kmo3smoSW4u=', 'xG5GW7NcTmkEfZRcHrlcP8kyWR8=', 'W5HAu8oCWRNcSc5f', 'W45sxSobWR3cSYy4WQZcV8kkWOmFBW==', 'b2NdMmkGW40uWRVcSW==', 'ct8UWPGr', 'WQG6WQPP', 'WRSdW7ldG8kb', 'WPNdHqPzlIBdKmkCW7G1', 'x3BdJwy=', 'wKOPACoppuCKnhb+mSkYWRSOkSk0', 'WP0CwCkqf8o2WRe=', 'aejFWPzoW4Cg', 'W5hcNLnWW6T7W7tdPczL', 'W4q0WOKCvX8cWRVdJmoGWQpdVSovyG==', 'WQ8bWPe=', 'WOqbyCoIWR47vvJdM1u=', 'p8kWW6xcHdn1WRDiWRmPWOrR', 'mJ/cLYugWO94WRXHWQb9WPNcLLq=', 'W6SErdjwDX7cMXJcTCkqrJlcNq==', 'WRaAWPTnuNdcMSotW47cGW==', 'WPnNu3RcVW==', 'aCoGz8oSWOtcNSoPpmowWPdcQmobv8oAv8o1A8oMkG==', 'WPS3y8k8Amo2WPtcKW==', 'u8k1W4qdWRPNW7VdM2xcIJhdRCo4', 'hJagWP0qW5hcVXK=', 'WPKzCSoGWPy=', 'W5b4F8o9WOq=', 'W4ldT8o8W7hcHSkJW7OYWPPJWOW=', 'WOtcQ8oYW6/cHmkAghtdRNXRoMq=', 'jSk1cSkVwSkiW7aYWP7cJepdOb0=', 'th0wu8k7', 'W7efuIfhtHK=', 'nCoXcW3dP8k4W6pcVa==', 'W65KwmoNWRlcTs5QWR7cU8kvWRyzEctdT8ka', 'WPTogLpcVbJcMKJdM29lW7L6fSk7', 'wq3cHudcSSkhW7u/WO3cSmoCW4W=', 'gMhdL8k4W4egWOZcI3nw', 'W4tcIIddHx4=', 'wCoLo2lcRW==', 'yMRdJw0=', 'E3hdMMacW6bT', 'W7P5n8o1zCkxW53dNKjRFmoReGlcTumdocNdLfZcS8oAWQBdJ8oOaWJcGqePWOyXW4pdRHj4WORdSW==', 'qmojWPhcJa==', 'sX3cK2RcS8kmW5K4WQ7cRCoqW4PBW40=', 'WPyjWO1RW6ycA8k4W4q=', 'WOq4WOJdGCkhDa==', 'WPCvW7ZdRMK2W6W3oSowh8kbh2xcPSkYWOBdICoRW6qDW7qkoq==', 'gJ3dJXaqCG0=', 'WOFcOCoZW57cI8knxwxdOv8=', 'W7tcOmkPW6hcJ8kWW6e/WPW=', 'kM5/', 'WOpdIqLvFshdNCkbW48NdSopEWtcVmkL', 'xgetrCkWhwi=', 'vxRdIKyvW4nKWQ8=', 'WOrNWOmepG==', 'WP0PW63dPmo0WRFdO8kxzK3dQHxcRmoD', 'WOxdIrzixtZdGSkwW48ZeCoxDGG=', 'dmkpf8kSumkuW7i=', 'm8kssmoUWPVcR3RdNCoM', 'emo5aSknWRJcGqy=', 'WQK4WR9LCuFdQmoZW6RcSGpcVW==', 'W5dcKKTmW7XWW5y=', 'CcPvW5FcNSo9iGhcScG=', 'xComW5u=', 'xCo6W4zrW53dKSo+WQvFFSkNxmoAWROuBGe=', 'W65sxG==', 'ErdcMq==', 'hCkzx8oCWPdcQMpdK8o6ASoIW4JdTmkXyNddN8kH', 'WRKhW5SOWRjdwcqX', 'eCkLdCku', 'tSo1W5vD', 't0eLDmkXnvqSv2XJmmk4WQq=', 'lmk5dCkF', 'WPFdLue9WR0=', 'WPe8W5C=', 'fCoKDCoAW4FcNmoJmmowWRFdOCoura==', 'uv3dN3yFW6XKWRbLWQr9WRFdIrvcWQRcGq==', 'WPiYWQPKivBcSmoQW7lcUb3cPtaTW5iOoGr9sSolWO0=', 'W4PiEmohWQtcRs5HWONcVCktWOSoBW==', 'WR9lbKZdVWdcIudcKa==', 'xSolWQfCy8oXbCkYW5e=', 'BmorFSkFWRq=', 'l8kwx8onWPFcUg/dRW==', 'jSk1cSkVxmkiW6mYWOlcJf7dQbfrW78=', 'uCoVovxcUmohcW==', 'W57cHhDZW7P0W4pdUarYrK4gWOi=', 'WPW2zCk2imkxWP/cKqyYFmkQw08=', 'jSoRWP4PW4tcTCkaoq==', 'WPpcImocWO9ZW5qHWPGN', 'cSkkW5WqFW==', 'x1y8DW==', 'FeePsmknkvW6', 'erJdVrCSxYSCrSoB', 'DCocW4JdHa0XESoS', 'bmkct8or', 'jmkTW7pcIh1HWPXsWRqU', 'W5iQW6bJAXtcTdOLia==', 'W63cRN1+W4K=', 'r8oFa8oBW5BcM15N', 'W4HoDCkE', 'dSoQdqBdOmkXW4tcUSoPEKxdJG==', 'uCoIphpcRq==', 'W6BcTfn9W40=', 'WP08ECkWn8owWPe=', 'W4vsxmoeWRxcOHL9WQVcQG==', 'kJnWW6i8W7u=', 'WOJcK8oeWO14W4OrWRiTW7Xfrq==', 'WPzxrW==', 'WOjih1O=', 'WORdJq1izYpdNCkU', 'W543WQqqaXGoWRhdUq==', 'W55+A8kDlW==', 'WOZcHSocWOfKW4aZWRu1', 'W5DEsmoCWOpcRZf9WOVcQ8kuWPyxzW==', 'WQTchwJcVaxcJuNcLwDqW54/', 'W7HAzSkpamklsHaXW7RcJmonnCkSWQu=', 'WR5gdL4=', 'W4SFrc1rzG==', 'W4qvW7rEBq==', 'lK1lWQjA', 'WQrNWRGvj2hcLSoRgG==', 'WRBdIrPXzZVdJCkhW6K1', 'nJddHq==', 'wSo9W55uWPxdL8ofWQ0CyW==', 'W6NcTrNdNXJdUSoaAXnblmkRlmofq8kr', 'mL17WPXQ', 'kmoQebFdUW==', 't8oDeSogW4/cMrTtWR1eCty=', 'WPy+WQnRDvS=', 'zmoFD8kYWPCD', 'WPKZW5BdQa==', 'k8kaW50OELJcUmoG', 'WRJdGGPzDHRdNG==', 'gsemWOaTW5/cHGNcSc7dOmor', 'WP3cPSo9WQe2WOu=', 'imoQWO42W4BcPCkammkxW4GEWPZdOa==', 'fmkgWOZcQeXZp8kGbSkzW67cNmkyBmoeuJ/cOf59ma1Hu8ogaSkKWRKZWP5XWORdRCo2WQddRCkGW5q=', 'W4LmymksfCkndbu8WR/cISoq', 'WReCW6tdLM4WW70+bCokeSkDcx8=', 'WOykBSoFWRm=', 'oCkEuSoqWPpcU2FcKSoSCSkVW47dOCkX', 'kSo3eqVdOCkHW5JcTG==', 'WQ40W57cLa==', 'h8oOCSoQ', 'WRmlW4ecWRDxr2mWWRTjxrdcVq==', 'WOddPCovt8olW4fNrmoLgXxcRG==', 'FCovW6tdPXG4ESo5z8oAWRRdLCookq==', 'EbBcGKFcUa==', 'W4CgWPCYCdC1WOVdNCox', 'y8ohW5JdRr4+FSoYtq==', 'WQyBtmkiWQpcRY99W7ldVG==', 'W6PAyCkt', 'qmo/wmkdWRPvCefIW4xcV8o4', 'WRKhW4eoWQHdrG==', 'W5a2W69KlGdcGZOTDblcJmkvECoBnG==', 'FJ8JW43cU8kmxNZdGa7cO8kqWR88WOpdPCkrWRedlstcPWRcRmklW43dMchdGa5vW73dJmo/', 'WPFcQ8o+W4JcTmkbb3tdG1PXng7cKa==', 'agjLWOv9W6O/xG==', 'y8oFWPdcJCkeWP88zWKmW7C6', 'wCoeWR5qiSo5bSkkW4tdI8o8', 'WO87W4BdV8oPWQRdO8kZ', 'r8kGW5uZWQ10W6RdKxNcQG==', 'WRFdNuaWWQVcMWJcUYKA', 'rNRdHNePW4zXWRHeWRb6WPtdGXK=', 'ESkXW4yXWRn0WR7dLwxcSd7dSG==', 'lMFdJSk6W4a=', 'D8ozWPBcSCkhWO5UybWeW78=', 'WP4PWQX7', 't8osd8oyWP/cMLPwWQi=', 'WRSWW43cSSozlby2'];
(function(_0x5bbe0b, _0x4f197e) {
    var _0x36686b = function(_0x5a92c9) {
        while (--_0x5a92c9) {
            _0x5bbe0b.push(_0x5bbe0b.shift());
        }
    };
    _0x36686b(++_0x4f197e);
}(_0x491d, -0x183f * 0x1 + 0x1 * 0x14d5 + 0x41a));
var _0x4708 = function(_0x478f88, _0x2283ea) {
    _0x478f88 = _0x478f88 - (-0x183f * 0x1 + 0x1 * 0x14d5 + 0x36a);
    var _0x105947 = _0x491d[_0x478f88];
    if (_0x4708.fZxFEc === undefined) {
        var _0x59340d = function(_0x1ab925) {
            var _0x1a971c = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=',
                _0x3cf0d7 = String(_0x1ab925)['replace'](/=+$/, '');
            var _0x46d15c = '';
            
            for (var _0x1c8182 = 0x528 * 0x7 + 0x19bc + 0xc * -0x527, _0xedbb50, _0x44f290, _0x1149f1 = -0x1a2d + -0x1 * 0xa76 + 0x24a3; _0x44f290 = _0x3cf0d7.charAt(_0x1149f1++); ~_0x44f290 && (_0xedbb50 = _0x1c8182 % (-0xd8f + 0x8 * -0x364 + 0x17 * 0x1c5) ? _0xedbb50 * (0x1f4 + 0x4e0 + -0x694) + _0x44f290 : _0x44f290, _0x1c8182++ % (-0x1f * -0x51 + 0x14 * 0x169 + -0x25ff * 0x1)) ? _0x46d15c += String.fromCharCode(-0x99a + 0x2533 + 0x2a9 * -0xa & _0xedbb50 >> (-(-0x14 * -0xb0 + -0x1 * 0x155b + 0x79d * 0x1) * _0x1c8182 & 0x60d * -0x3 + 0x29 * -0xc1 + 0x3d * 0xce)) : -0xc23 + -0x1b2d + 0x2750) {
                _0x44f290 = _0x1a971c.indexOf(_0x44f290);
            }
            return _0x46d15c;
        };
        var _0x4fb7ba = function(_0x3520b6, _0x16e645) {
            var _0x4cfdab = [],
                _0x576f90 = 0x643 * -0x4 + 0x2565 + -0xc59,
                _0x2ada91, _0x4d07a9 = '',
                _0x4fe9ff = '';
            _0x3520b6 = _0x59340d(_0x3520b6);
            for (var _0x3de0a9 = -0x20a9 + 0x23 * -0x7f + 0x3206, _0x3ccb0a = _0x3520b6.length; _0x3de0a9 < _0x3ccb0a; _0x3de0a9++) {
                _0x4fe9ff += '%' + ('00' + _0x3520b6.charCodeAt(_0x3de0a9)['toString'](0xb02 * 0x1 + -0x1a53 + 0xf61))['slice'](-(0xf3d + 0x1136 + -0x2071));
            }
            _0x3520b6 = decodeURIComponent(_0x4fe9ff);
            var _0x418d36;
            for (_0x418d36 = 0x263f * -0x1 + -0x776 + 0x2db5; _0x418d36 < -0x1 * 0x21e9 + -0x1c3f + 0x3f28; _0x418d36++) {
                _0x4cfdab[_0x418d36] = _0x418d36;
            }
            for (_0x418d36 = -0x1 * 0x1bcd + 0xf * 0x290 + 0xaa3 * -0x1; _0x418d36 < -0x3 * -0x144 + 0x2548 + -0xd5c * 0x3; _0x418d36++) {
                _0x576f90 = (_0x576f90 + _0x4cfdab[_0x418d36] + _0x16e645.charCodeAt(_0x418d36 % _0x16e645.length)) % (0x1ffd * 0x1 + 0x25fe + 0x1 * -0x44fb), _0x2ada91 = _0x4cfdab[_0x418d36], _0x4cfdab[_0x418d36] = _0x4cfdab[_0x576f90], _0x4cfdab[_0x576f90] = _0x2ada91;
            }
            _0x418d36 = 0x4f * -0x8 + 0x10b1 + -0xe39, _0x576f90 = 0x6ce * 0x1 + 0x20c8 + 0x1 * -0x2796;
            for (var _0x51e723 = 0x1869 + -0x1 * 0x25f3 + 0xd8a; _0x51e723 < _0x3520b6.length; _0x51e723++) {
                _0x418d36 = (_0x418d36 + (0x14ad + 0x1 * 0x1b4f + -0x2ffb)) % (0x94 * -0x3a + -0x7 * -0xfb + 0x3 * 0x939), _0x576f90 = (_0x576f90 + _0x4cfdab[_0x418d36]) % (0x1 * 0x1075 + 0x47 * 0x46 + -0x1 * 0x22df), _0x2ada91 = _0x4cfdab[_0x418d36], _0x4cfdab[_0x418d36] = _0x4cfdab[_0x576f90], _0x4cfdab[_0x576f90] = _0x2ada91, _0x4d07a9 += String.fromCharCode(_0x3520b6.charCodeAt(_0x51e723) ^ _0x4cfdab[(_0x4cfdab[_0x418d36] + _0x4cfdab[_0x576f90]) % (-0x112e + 0x1 * -0x1262 + 0x2490)]);
            }
            return _0x4d07a9;
        };
        _0x4708.jvsUfa = _0x4fb7ba, _0x4708.tLdSfI = {}, _0x4708.fZxFEc = !![];
    }
    var _0xa28d90 = _0x4708.tLdSfI[_0x478f88];
    return _0xa28d90 === undefined ? (_0x4708.cZFwfN === undefined && (_0x4708.cZFwfN = !![]), _0x105947 = _0x4708.jvsUfa(_0x105947, _0x2283ea), _0x4708.tLdSfI[_0x478f88] = _0x105947) : _0x105947 = _0xa28d90, _0x105947;
};
var username = '000',
    usernames = new Array(),
    heavy_cache = UI.GetValue('Rage', 'HEAVY PISTOL', 'Targeting', 'Minimum damage'),
    scout_cache = UI.GetValue('Rage', 'SCOUT', 'Targeting', 'Minimum damage'),
    awp_cache = UI.GetValue('Rage', 'AWP', 'Targeting', 'Minimum damage'),
    auto_cache = UI.GetValue('Rage', 'AUTOSNIPER', 'Targeting', 'Minimum\x20damage'),
    weapon_name_ds = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer())),
    heavy_cache_ds = UI.GetValue('Rage', 'HEAVY PISTOL', 'Targeting', 'Minimum damage'),
    scout_cache_ds = UI.GetValue('Rage', 'SCOUT', 'Targeting', 'Minimum damage'),
    auto_cache_ds = UI.GetValue('Rage', 'AUTOSNIPER', 'Targeting', 'Minimum damage');
usernames.push('allthepeopleshoulduseosu'), usernames.push('Nadindi'), usernames.push('GVK27'), UI.AddLabel('                 Watermark            '), UI.AddColorPicker('Watermark'), UI.AddCheckbox('Rainbow bar');
Cheat.Print("\n\n\x48\x56\x48\x20\x45\x73\x73\x65\x6e\x74\x69\x61\x6c\x73\x20\x5b\x31\x34\x74\x68\x20\x4a\x75\x6c\x79\x5d\x20\x63\x72\x61\x63\x6b\x65\x64\x20\x62\x79\x20\x74\x72\x61\x70\x73\x74\x61\x72\n\n\n"); UI.AddLabel("\x43\x72\x61\x63\x6b\x65\x64\x20\x62\x79\x20\x74\x72\x61\x70\x73\x74\x61\x72");
var color = UI.GetColor('Misc', 'JAVASCRIPT', 'Script items', 'Watermark');
color[0xa84 + -0x1 * -0x68f + -0x1110] == -0x4f * -0x23 + -0x3e7 + -0x6e6 && UI.SetColor('Misc', 'JAVASCRIPT', 'Script items', 'Watermark', [0x1d99 * 0x1 + 0x6d3 * -0x3 + -0x821, -0x1e67 + 0x2516 + -0x5b0, 0x821 + 0x1 * -0x166 + -0x2de * 0x2, 0x24a1 + -0xb * -0x28b + -0x3f9b]);

function isActive(_0x433e1a) {
    return UI.IsHotkeyActive('Script items', _0x433e1a);
}

function setValue(_0x2325b3, _0x299196) {
    UI.SetValue('Rage', _0x2325b3.toUpperCase(), 'Targeting', 'Minimum\x20damage', _0x299196);
}

function isHeavyPistol(_0x5c0241) {
    if (_0x5c0241 == 'r8 revolver' || _0x5c0241 == 'desert\x20eagle') return !![];
}

function isAutoSniper(_0x12b09a) {
    if (_0x12b09a == 'scar 20' || weapon_name == 'g3sg1') return !![];
}
var restore_values = ![],
    restore_values_ds = ![];

function draw() {
    if (usernames.indexOf(Cheat.GetUsername()) == -1) {
        if ('KOagd' !== 'hYzoc') {
            if (!World.GetServerString()) return;
            var _0x49aa07 = new Date(),
                _0x446367 = _0x49aa07.getHours() + ':',
                _0x5ec783 = _0x49aa07.getMinutes() + ':',
                _0x38cb33 = _0x49aa07.getSeconds();
            color = UI.GetColor('Misc', 'JAVASCRIPT', 'Script\x20items', 'Watermark');
            var _0x228e69 = Render.AddFont('Verdana', -0x1939 + 0x2311 + -0x7 * 0x167, -0x828 + -0x168d + 0xb * 0x2ef),
                _0x5d89c1 = 'skeet.cc [metadebug] | mayori\x20|\x20delay:\x20' + Math.round(Entity.GetProp(Entity.GetLocalPlayer(), 'CPlayerResource', 'm_iPing'))['toString']() + 'ms | ' + Globals.Tickrate()['toString']() + 'tick | ' + _0x446367 + _0x5ec783 + _0x38cb33,
                _0x3331b7 = -0x43 * -0x61 + 0x1693 + 0x1 * -0x2fe4,
                _0x2b7c12 = Render.TextSizeCustom(_0x5d89c1, _0x228e69)[-0x6 * 0x34b + -0x2 * 0x55a + 0x1e76] + (0x21ee + -0x4fc + 0x1 * -0x1cea),
                _0x119cad = Global.GetScreenSize()[0x238f * -0x1 + -0x6 * 0x415 + -0x1 * -0x3c0d],
                _0x5b0a3b = -0xcd3 + 0xd4d * -0x1 + -0xd15 * -0x2;
            _0x119cad = _0x119cad - _0x2b7c12 - (-0x807 + 0x1 * -0x1cf + -0x4 * -0x278), Render.FilledRect(_0x119cad, _0x5b0a3b, _0x2b7c12, -0x362 * -0x8 + -0x6f * 0x5 + -0x18e3, [color[0x12b4 + 0x1f7 * -0x6 + -0x6ea], color[-0x257b + 0x12b3 * 0x2 + 0x16], color[-0x1fc0 + 0x17 * -0x29 + 0x1 * 0x2371], -0x206 + -0x1 * 0x1b7f + -0x2 * -0xf42]), Render.FilledRect(_0x119cad, _0x5b0a3b + (-0x7b0 + 0x1f98 + -0x17e6), _0x2b7c12, _0x3331b7, [0x1782 + 0x1409 * 0x1 + -0x2b7a, -0x1 * -0x219e + 0x15 * 0x18f + -0xb0c * 0x6, 0x3 * 0x47f + -0xbae * -0x1 + 0x15 * -0x132, color[-0x5e3 + 0x2655 + -0x206f]]), Render.StringCustom(_0x119cad + (-0x1 * -0x87 + 0xfa8 + 0x102a * -0x1), _0x5b0a3b + (-0x268f + 0x1 * 0x16e3 + 0x135 * 0xd), -0x1 * -0x1c27 + 0x195e + -0x3585, _0x5d89c1, [0x2e * -0x3e + -0xb14 * 0x3 + -0x2c6 * -0x10, -0x158f + 0x16a6 + -0x117, 0x1566 + -0x548 + -0x101e, 0x2277 + -0x51c + -0x1ca7], _0x228e69), Render.StringCustom(_0x119cad + (-0x2 * -0x98c + -0x1 * -0x1a7e + -0x2d92 * 0x1), _0x5b0a3b + (-0x1e71 * -0x1 + 0x1862 + -0x36cf), -0x5 * 0x1ed + 0x1d * -0x3 + 0x9f8, _0x5d89c1, [0x2131 + -0x21a2 + -0xb8 * -0x2, 0x1 * 0x657 + 0x84 + -0x3 * 0x1f4, 0x1 * -0x3cd + 0x2387 + 0x1ebb * -0x1, -0x117d + -0x190 * -0x16 + -0x3 * 0x54c], _0x228e69);
        } else {
            function _0x10b07c() {
                if (name == 'r8\x20revolver' || name == 'desert eagle') return !![];
            }
        }
    } else {
        if ('PGPWC' === 'YSxfN') {
            function _0x46510b() {
                Render.FilledRect(-0x964 + -0x21f * 0x11 + -0x5 * -0x917, 0x8e1 + 0x13 * -0x12f + 0xd9c, Global.GetScreenSize()[0x8d * -0x43 + -0x1aa6 * -0x1 + 0xa41], Global.GetScreenSize()[-0xedd * -0x2 + 0x13 * 0x15c + -0x1 * 0x378d] / (0x14f * 0x1a + -0x1f * -0x99 + -0x1 * 0x348b), [0x112 * -0x17 + 0x243b + -0xb9d, -0x1e * -0x101 + -0x1 * 0x26f3 + 0x989, 0xb93 * 0x2 + 0x1 * 0x386 + -0x3ab * 0x7, -0x4a * 0x59 + -0x1973 + 0x4 * 0xd0b]), Render.FilledRect(-0x97 + 0x1 * -0xc5 + 0x15c, Global.GetScreenSize()[0xfe0 + -0x9 * 0x2e6 + 0xa37] / (0xae8 + 0x30d * 0x9 + 0x3 * -0xcc9), Global.GetScreenSize()[-0x22de + -0x17b2 + 0x3a90], Global.GetScreenSize()[0x17b * -0x16 + -0x1 * -0x134 + 0x1f5f] / (-0x309 * 0x1 + 0x3 * 0xfb + 0x1a), [0x44f + -0x1fa5 * -0x1 + -0x22f5, -0x2ab * 0x1 + 0x5 * -0x413 + 0x1809, 0x3b * -0x13 + 0x58c + -0xd * 0x17, -0x819 * -0x2 + -0x639 + -0x8fa]);
            }
        } else Render.FilledRect(0x2 * -0xe53 + 0x12cf + 0xb * 0xe5, -0x4 * 0x60d + 0x223e + -0xa0a, Global.GetScreenSize()[0x3fd * 0x2 + 0x749 + -0xf43], Global.GetScreenSize()[0xb9b * -0x3 + -0x1071 + -0x4a9 * -0xb] / (0x1955 + -0x265 * -0xf + -0x3d3e), [-0x3 * -0x74c + 0x11 * 0xaa + 0x89 * -0x3e, -0x1fa6 + 0x874 * 0x4 + -0x176, -0x24e5 + 0x15bc + 0x1028, 0x2437 + 0xf6 * 0x2 + 0x1292 * -0x2]), Render.FilledRect(0x4 * 0x3ea + 0x244b + -0xd * 0x3ff, Global.GetScreenSize()[0xd3 * -0x2 + -0x1457 + 0x15fe] / (-0xbc2 + 0x503 + 0x6c1), Global.GetScreenSize()[0x23bf + -0xc + 0xd * -0x2bf], Global.GetScreenSize()[0x1 * -0xd55 + 0x1 * 0x1b56 + -0xe00] / (-0x13dc + 0xc1a + -0x1 * -0x7c4), [0x299 * -0x1 + -0x1976 + -0xe87 * -0x2, -0x13a2 + -0x1 * 0x1ad7 + 0x2f78, 0x1999 + 0x1493 + 0x2e2c * -0x1, 0x5d0 * 0x3 + -0x792 + -0x8df]);
    }
}
Cheat.RegisterCallback('Draw', 'draw'), UI.AddLabel('               Spectator list            ');
const x2 = UI.AddSliderInt('window_x', -0x1d59 + -0x39a + -0x23 * -0xf1, Global.GetScreenSize()[-0x12d2 + -0x7 * -0x4d6 + 0xf08 * -0x1]),
    y2 = UI.AddSliderInt('window_y', 0x1b7 * 0x1 + 0x14d5 + 0x4a * -0x4e, Global.GetScreenSize()[-0xf8e * 0x1 + -0x10d4 + 0x2063]);
UI.AddColorPicker('Spec list');
var colorspec = UI.GetColor('Misc', 'JAVASCRIPT', 'Script items', 'Spec list');




function in_bounds(_0x4b2e0e, _0x7f19fc, _0x5c9d3c, _0xa655f3, _0x5164b8) {
    return _0x4b2e0e[0x980 + -0x38b * -0x6 + 0x3e * -0x7f] > _0x7f19fc && _0x4b2e0e[-0x1 * -0x909 + -0x1e0e + 0x1506] > _0x5c9d3c && _0x4b2e0e[-0x1ec + 0x1c9 * -0x13 + 0x23d7] < _0xa655f3 && _0x4b2e0e[0x1 * -0x571 + -0x23d * 0xd + 0x228b] < _0x5164b8;
}

function main() {
    if (usernames.indexOf(Cheat.GetUsername()) == -1) {
        const _0x343929 = UI.GetValue('Misc', 'JAVASCRIPT', 'Script items', 'window_x'),
            _0x5dd330 = UI.GetValue('Misc', 'JAVASCRIPT', 'Script\x20items', 'window_y');
        colorspec = UI.GetColor('Misc', 'JAVASCRIPT', 'Script items', 'Spec\x20list');
        var _0x434f98 = Render.AddFont('Verdana', -0xda * 0x20 + -0x3 * -0xcb9 + -0x29 * 0x44, 0x784 + 0x335 * -0x1 + -0x3eb);
        const _0x557342 = get_spectators();
        if (_0x557342.length > 0x12e9 * -0x1 + -0x188d + 0x2b76) {
            Render.FilledRect(_0x343929 + (-0x2399 + -0x1e84 + 0xd3a * 0x5), _0x5dd330 + (0x93d + -0x2 * -0x4db + -0x12f0), -0x3 * -0x694 + -0x24e0 + 0x47b * 0x4, 0x1 * -0x1327 + 0x1154 + 0x1d5, [colorspec[-0x15c6 + -0x2203 + 0x37c9], colorspec[-0x92 * 0xd + 0x237 + -0x4 * -0x14d], colorspec[0xcb0 + -0x1600 + 0x952], -0xbae * 0x2 + 0x1b7 * 0x11 + -0x4cc]), Render.FilledRect(_0x343929 + (0x2 * -0x5e0 + -0x1d28 + 0x28ed), _0x5dd330 + (0x1 * 0x25f + 0x1e48 + -0x20a2), -0x1217 + -0xfdf + 0x22be, -0x1232 + 0x230d + -0x10c9 * 0x1, [-0xcf0 + -0x2037 + 0x2 * 0x169c, 0x76 * -0x2b + -0x621 + -0x6f * -0x3c, 0xf06 * 0x1 + -0x11 * -0x1c5 + -0x2d0a, 0x60c + 0x1ccd + -0x21da * 0x1]), Render.StringCustom(_0x343929 + (0x11eb * 0x2 + 0x77e + -0x6 * 0x728) - Render.TextSizeCustom('Spectators', _0x434f98)[-0x5 * 0x2 + 0x269d + 0x7d * -0x4f] / (0x21ac + 0x22b9 + -0x4463) + (0x2564 + 0xda1 + -0x7a * 0x6b), _0x5dd330 + (-0x5ad * 0x2 + -0x20de + 0x1 * 0x2c41), 0x1255 + -0x3b * -0x74 + -0x2d11, 'Spectators', [-0xebf + 0x65d + 0x862, -0x446 * -0x4 + -0x5 * -0x96 + -0x2 * 0xa03, -0x295 * 0x3 + 0x1 * -0x1763 + -0x31d * -0xa, 0x267f + 0xcdb * 0x3 + -0x2 * 0x262e], _0x434f98), Render.StringCustom(_0x343929 + (-0x13 * -0xe7 + -0xe4a + -0x277) - Render.TextSizeCustom('Spectators', _0x434f98)[0x1 * 0x1019 + 0x198e + 0x29a7 * -0x1] / (-0x17e0 + -0x14a6 + -0x64 * -0x72) + (0x268c * -0x1 + -0x2 * 0xced + 0x406c), _0x5dd330 + (0xed1 + 0xf52 + 0x1e1b * -0x1), 0x223d + 0x1 * -0x1b91 + -0x3d * 0x1c, 'Spectators', [-0x19 * 0x2e + -0x5 * 0x713 + 0x28dc, 0x425 + -0x1 * -0x1bd3 + -0x1ef9, -0x1ebb + -0x17b * 0x11 + 0xf * 0x3cb, 0x29 * -0x79 + -0x1270 + -0x5c * -0x6c], _0x434f98), Render.FilledRect(_0x343929 + (-0x2 * -0xd99 + -0x6 * -0x557 + -0x1e9 * 0x1f), _0x5dd330 + (0xcf8 + 0x2422 + 0x3103 * -0x1), -0x25c1 + -0x33b * 0xb + 0x4a12, (0x11 * -0x229 + 0xb * -0x229 + 0x3c8e) * _0x557342.length, [0x2d4 * -0x6 + 0x1087 + -0x1 * -0x82, 0xb7e + -0xa81 * -0x1 + -0x15ee, 0x266e + -0x92d + -0x1d30, colorspec[-0x1 * 0xb79 + 0x1 * -0x212c + -0x8 * -0x595]]);
            for (i = 0x17cc + 0x16e6 + -0x2eb2; i < _0x557342.length; i++) {
                Render.StringCustom(_0x343929 + (0x1288 + -0x2 * 0xd0e + 0x7ff) - Render.TextSizeCustom(_0x557342[i], _0x434f98)[-0x46f + 0x45 * 0x49 + -0xf3e] / (-0x51e + 0x2 * -0x74a + 0x13b4), _0x5dd330 + (-0x1 * -0x1a15 + -0x419 * -0x3 + -0xcc2 * 0x3) + (0x21 * -0x71 + -0x198 + -0xf * -0x115) * i, -0xc0e + 0x20a4 + -0x3e * 0x55, _0x557342[i], [0x2f8 * -0x8 + 0xe8d + 0x933, -0x18d5 + -0x10ce + 0x29a3, -0x29b + -0x656 + 0x8f1, 0x71b + 0xb14 + -0x117b], _0x434f98), Render.StringCustom(_0x343929 + (0x33 * 0x4e + 0x29 * -0x8e + -0x1e * -0x41) - Render.TextSizeCustom(_0x557342[i], _0x434f98)[-0x208d + 0x1634 * 0x1 + 0xa59] / (0x1306 + -0x1196 * 0x2 + 0x1028), _0x5dd330 + (0x1a0 + -0x6 * 0x41b + 0x1 * 0x171b) + (-0x1 * 0xc09 + -0x8 * 0x171 + 0x17a3) * i, 0x2524 * -0x1 + 0x11ed + 0x1337, _0x557342[i], [0x1392 + -0x1acb + 0x4 * 0x20e, -0x1461 + 0x606 * -0x4 + 0x18 * 0x1e5, -0xb40 + -0x17f * -0x6 + 0x345, -0x14 * -0x25 + 0xb47 + -0x4 * 0x34b], _0x434f98);
            }
        }
    } else Render.FilledRect(-0x127c + 0x14d5 + 0x1 * -0x259, -0x1 * 0x1111 + -0xd1 + -0x2fb * -0x6, Global.GetScreenSize()[-0x1280 + -0x425 + -0xbb * -0x1f], Global.GetScreenSize()[0x1a * -0x3 + -0x1a1b + -0x6 * -0x467] / (0x4f * -0x3 + -0x23f5 * 0x1 + 0x313 * 0xc), [-0x1418 + 0x62 + -0x57 * -0x3a, -0x195d + -0x1ea5 + -0xe * -0x40d, -0x8 * -0x7b + -0x236d + 0x2094, -0x1dc1 + -0x7 * -0x16f + -0x1 * -0x14b7]), Render.FilledRect(-0x5 * -0x58a + -0x317 * 0x1 + -0x1 * 0x189b, Global.GetScreenSize()[0x6ef + 0x1 * -0x2185 + 0x1a97 * 0x1] / (0x10f4 + -0x4 * 0x6da + 0xa76), Global.GetScreenSize()[-0x23e7 + 0x9d * 0x4 + 0x2173 * 0x1], Global.GetScreenSize()[-0xb9f + -0x147b + 0x201b * 0x1] / (-0x7f * 0x2c + 0x60d * 0x6 + -0xe78 * 0x1), [0x1e9e * 0x1 + -0x2084 + -0xd * -0x39, -0x1e55 + -0x463 + 0x23b7, 0x2 * -0x1ba + 0x35b * 0x7 + -0x1409, -0x214 + -0x22fd + -0xe * -0x2b8]);
}
Global.RegisterCallback('Draw', 'main'), UI.AddLabel('                   Hotkeys            ');
const x1 = UI.AddSliderInt('Hotkeys_x', -0x49d + -0x75c * -0x1 + -0x2bf, Global.GetScreenSize()[0x243a + -0xf01 + 0x3 * -0x713]),
    y1 = UI.AddSliderInt('Hotkeys_y', 0x38e + -0x10dd + 0x1 * 0xd4f, Global.GetScreenSize()[-0x2006 + 0x1 * 0x449 + 0x35 * 0x86]);
UI.AddColorPicker('Hotkeys');
var colorhotkeys = UI.GetColor('Misc', 'JAVASCRIPT', 'Script items', 'Hotkeys');
colorhotkeys[-0xa67 * -0x1 + 0xa4f + -0x14b3] == 0x1aac + 0x61f * 0x4 + 0x4 * -0xcca && UI.SetColor('Misc', 'JAVASCRIPT', 'Script\x20items', 'Hotkeys', [0x7dc + -0x54 * -0x47 + -0x1ecf, 0x177 * -0x2 + -0x7ae * 0x5 + 0x29cb, -0x1735 + -0x1912 + 0x3136, 0xa1e + 0xee6 + -0x1901 * 0x1]);
var alpha = 0x1 * -0x40d + 0x20a * -0xe + -0x685 * -0x5,
    maxwidth = 0x2586 + 0x8 * -0x17b + -0x19ae,
    swalpha = 0x6 * 0xe8 + 0x7 * -0x30 + -0x420,
    fdalpha = 0x2424 + 0x1 * 0x157d + -0x39a1 * 0x1,
    apalpha = -0x1eda + 0xcc0 + 0x121a * 0x1,
    aialpha = 0x47c + 0x1c97 + -0x2113,
    spalpha = 0x265 * 0x7 + -0x1ad7 * -0x1 + -0x2b9a,
    fbalpha = 0x1f28 + -0x244f + 0x527,
    dtalpha = 0x9fb * 0x1 + -0x1dc1 + 0x13c6,
    hsalpha = -0xad * -0x1c + -0x1e76 + 0xb8a,
    doalpha = 0x2393 * 0x1 + 0x1 * -0x1369 + 0x102a * -0x1,
    textalpha = -0xa * -0x1b7 + -0x1005 * -0x2 + -0x3130,
    h = new Array();

function in_bounds(_0x1808d2, _0x3e8774, _0x27876a, _0x45af58, _0x27c956) {
    return _0x1808d2[0x1396 + 0x1042 + -0x23d8] > _0x3e8774 && _0x1808d2[0x2472 + -0x26dc + 0x26b] > _0x27876a && _0x1808d2[0x1c01 + -0x26a9 + -0xaa8 * -0x1] < _0x45af58 && _0x1808d2[-0x383 * 0x8 + 0x2f9 * -0x7 + -0x8 * -0x61d] < _0x27c956;
}



function in_bounds(_0x5365fb, _0xfcc607, _0x46ee89, _0x4091d1, _0x3b3873) {
    return _0x5365fb[-0x1118 + 0x39 + 0x10df] > _0xfcc607 && _0x5365fb[0x9 * -0x8d + 0x70 * 0x35 + -0x123a] > _0x46ee89 && _0x5365fb[0x2b * -0x8e + -0x1403 + 0x2bdd] < _0x4091d1 && _0x5365fb[-0x3 * -0x472 + -0x23e3 + 0xb47 * 0x2] < _0x3b3873;
}

//Anti-aims
UI.AddLabel("                   Antiaim            ");
UI.AddSliderInt("Antiaim_x", 0, Global.GetScreenSize()[0]);
UI.AddSliderInt("Antiaim_y", 0, Global.GetScreenSize()[1]);


function in_bounds(vec, x, y, x2, y2) {
    return (vec[0] > x) && (vec[1] > y) && (vec[0] < x2) && (vec[1] < y2)
}

function draw_arc(x, y, radius, start_angle, percent, thickness, color) {
        var precision = (2 * Math.PI) / 30;
        var step = Math.PI / 180;
        var inner = radius - thickness;
        var end_angle = (start_angle + percent) * step;
        var start_angle = (start_angle * Math.PI) / 180;

        for (; radius > inner; --radius) {
            for (var angle = start_angle; angle < end_angle; angle += precision) {
                var cx = Math.round(x + radius * Math.cos(angle));
                var cy = Math.round(y + radius * Math.sin(angle));

                var cx2 = Math.round(x + radius * Math.cos(angle + precision));
                var cy2 = Math.round(y + radius * Math.sin(angle + precision));

                Render.Line(cx, cy, cx2, cy2, color);
            }
        }
}

function main_aa() {
    if (!World.GetServerString()) return;

    const x = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Antiaim_x"),
        y = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Antiaim_y");

    var font = Render.AddFont("Verdana", 7, 100);
    var RealYaw = Local.GetRealYaw();
    var FakeYaw = Local.GetFakeYaw();
    var delta = Math.min(Math.abs(RealYaw - FakeYaw) / 2, 60).toFixed(1);
    var safety = Math.min(Math.round(1.7 * Math.abs(delta)), 100);
    if (UI.IsHotkeyActive("Anti-Aim", "Fake angles", "Inverter")) {
        var side = "<";
    } else {
        var side = ">";
    }
    var text = "    FAKE (" + delta.toString() + "  ) | safety: " + safety.toString() + "% | side: " + side;
    var w = Render.TextSizeCustom(text, font)[0] + 8;

    Render.FilledRect(x - w, y, w, 2, [89, 119, 239, 255]);
    Render.FilledRect(x - w, y + 2, w, 18, [17, 17, 17, 255]);
    Render.StringCustom(x + 5 - w, y + 5, 0, text, [0, 0, 0, 180], font);
    Render.StringCustom(x + 4 - w, y + 4, 0, text, [255, 255, 255, 255], font);
    Render.Circle(x + 18 - w + Render.TextSizeCustom("FAKE (" + delta.toString(), font)[0], y + 8, 1, [255, 255, 255, 255]);
    draw_arc(x + 7 - w, y + 10, 5, 0, delta * 6, 2, [89, 119, 239, 255]);
    if (Global.IsKeyPressed(1) && UI.IsMenuOpen()) {
        const mouse_pos = Global.GetCursorPosition();
        if (in_bounds(mouse_pos, x - w, y, x + w, y + 30)) {
            UI.SetValue("Misc", "JAVASCRIPT", "Script items", "Antiaim_x", mouse_pos[0] + w / 2);
            UI.SetValue("Misc", "JAVASCRIPT", "Script items", "Antiaim_y", mouse_pos[1] - 20);
        }
    }
}

Global.RegisterCallback("Draw", "main_aa");
function get_icon(_0x2c2abc) {
    var _0x13be03 = '';
    switch (_0x2c2abc) {
        case 'desert eagle':
            _0x13be03 = 'a';
            break;
        case 'dual berettas':
            _0x13be03 = 'b';
            break;
        case 'five seven':
            _0x13be03 = 'c';
            break;
        case 'glock\x2018':
            _0x13be03 = 'd';
            break;
        case 'ak 47':
            _0x13be03 = 'e';
            break;
        case 'aug':
            _0x13be03 = 'f';
            break;
        case 'awp':
            _0x13be03 = 'g';
            break;
        case 'famas':
            _0x13be03 = 'h';
            break;
        case 'm249':
            _0x13be03 = 'i';
            break;
        case 'g3sg1':
            _0x13be03 = 'j';
            break;
        case 'galil ar':
            _0x13be03 = 'k';
            break;
        case 'm4a4':
            _0x13be03 = 'l';
            break;
        case 'm4a1 s':
            _0x13be03 = 'm';
            break;
        case 'mac\x2010':
            _0x13be03 = 'n';
            break;
        case 'p2000':
            _0x13be03 = 'o';
            break;
        case 'mp5 sd':
            _0x13be03 = 'p';
            break;
        case 'ump\x2045':
            _0x13be03 = 'q';
            break;
        case 'xm1014':
            _0x13be03 = 'r';
            break;
        case 'pp bizon':
            _0x13be03 = 's';
            break;
        case 'mag 7':
            _0x13be03 = 't';
            break;
        case 'negev':
            _0x13be03 = 'u';
            break;
        case 'sawed\x20off':
            _0x13be03 = 'v';
            break;
        case 'tec 9':
            _0x13be03 = 'w';
            break;
        case 'zeus\x20x27':
            _0x13be03 = 'x';
            break;
        case 'p250':
            _0x13be03 = 'y';
            break;
        case 'mp7':
            _0x13be03 = 'z';
            break;
        case 'mp9':
            _0x13be03 = 'A';
            break;
        case 'nova':
            _0x13be03 = 'B';
            break;
        case 'p90':
            _0x13be03 = 'C';
            break;
        case 'scar\x2020':
            _0x13be03 = 'D';
            break;
        case 'sg 553':
            _0x13be03 = 'E';
            break;
        case 'ssg 08':
            _0x13be03 = 'F';
            break;
        case 'knife':
            _0x13be03 = 'G';
            break;
        case 'flashbang':
            _0x13be03 = 'H';
            break;
        case 'high explosive grenade':
            _0x13be03 = 'I';
            break;
        case 'smoke grenade':
            _0x13be03 = 'J';
            break;
        case 'molotov':
            _0x13be03 = 'K';
            break;
        case 'decoy grenade':
            _0x13be03 = 'L';
            break;
        case 'incendiary grenade':
            _0x13be03 = 'M';
            break;
        case 'c4 explosive':
            _0x13be03 = 'N';
            break;
        case 'usp s':
            _0x13be03 = 'P';
            break;
        case 'cz75\x20auto':
            _0x13be03 = 'Q';
            break;
        case 'r8 revolver':
            _0x13be03 = 'R';
            break;
        case 'bayonet':
            _0x13be03 = 'V';
            break;
        case 'flip knife':
            _0x13be03 = 'W';
            break;
        case 'gut knife':
            _0x13be03 = 'X';
            break;
        case 'karambit':
            _0x13be03 = 'Y';
            break;
        case 'm9 bayonet':
            _0x13be03 = 'Z';
            break;
        case 'falchion knife':
            _0x13be03 = '1';
            break;
        case 'bowie knife':
            _0x13be03 = '2';
            break;
        case 'butterfly knife':
            _0x13be03 = '3';
            break;
        case 'shadow daggers':
            _0x13be03 = '4';
            break;
        case 'ursus knife':
            _0x13be03 = '5';
            break;
        case 'navaja knife':
            _0x13be03 = '6';
            break;
        case 'stiletto knife':
            _0x13be03 = '7';
            break;
        case 'skeleton knife':
            _0x13be03 = '8';
            break;
        case 'huntsman knife':
            _0x13be03 = '0';
            break;
        case 'talon knife':
            _0x13be03 = '8';
            break;
        case 'classic knife':
            _0x13be03 = '25';
            break;
        case 'paracord knife':
            _0x13be03 = 'Z';
            break;
        case 'survival knife':
            _0x13be03 = 'Z';
            break;
        case 'nomad knife':
            _0x13be03 = 'Z';
            break;
        default:
            _0x13be03 = '';
            break;
    }
    return _0x13be03;
}
UI.AddLabel("                   Tickbase            ");
UI.AddSliderInt("Tickbase_x", 0, Global.GetScreenSize()[0]);
UI.AddSliderInt("Tickbase_y", 0, Global.GetScreenSize()[1]);

function in_bounds(vec, x, y, x2, y2) {
    return (vec[0] > x) && (vec[1] > y) && (vec[0] < x2) && (vec[1] < y2)
}
var fa = 0;
var sa = 0;

function main_dt() {
    if (!World.GetServerString()) return;

    const x = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Tickbase_x"),
        y = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Tickbase_y");

    localplayer_index = Entity.GetLocalPlayer();
    localplayer_weapon = Entity.GetWeapon(localplayer_index);
    weapon_name = Entity.GetName(localplayer_weapon);
    g_Local_classname = Entity.GetClassName(localplayer_weapon);
    var nextattack = Entity.GetProp(localplayer_weapon, "CBaseCombatWeapon", "m_flNextPrimaryAttack");
    var CanShoot = false;
    if (nextattack <= Globals.Curtime()) {
        CanShoot = true;
    }

    var frames = 8 * Globals.Frametime();

    var font = Render.AddFont("Verdana", 7, 100);
    var fontbullet = Render.AddFont("bullet", 18, 100);
    if (CanShoot && Exploit.GetCharge() == 1 && UI.IsHotkeyActive("Rage", "Exploits", "Doubletap")) {
        var text = "DT [v3.9 metadebug] | tickbase(v): 16";
        var color = [89, 119, 239, 255];
    } else if (CanShoot && Exploit.GetCharge() == 1 && UI.IsHotkeyActive("Rage", "Exploits", "Hide shots")) {
        var text = "DT [v3.9 metadebug] | tickbase(v): 7";
        var color = [89, 119, 239, 255];
    } else {
        var text = "DT [v3.9 metadebug] | tickbase(v): 0";
        var color = [89, 119, 239, 255];
    }
    var w = Render.TextSizeCustom(text, font)[0] + 8;

    Render.FilledRect(x, y, w, 2, color);
    Render.FilledRect(x, y + 2, w, 18, [17, 17, 17, 255]);
    Render.StringCustom(x + 5, y + 5, 0, text, [0, 0, 0, 180], font);
    Render.StringCustom(x + 4, y + 4, 0, text, [255, 255, 255, 255], font);

    Render.String(x + 4, y + 22, 0, get_icon(weapon_name), [255, 255, 255, 255], 5);
    if ((g_Local_classname == "CKnife" ||  g_Local_classname == "CHEGrenade" || g_Local_classname == "CMolotovGrenade" || g_Local_classname == "CIncendiaryGrenade" || g_Local_classname == "CFlashbang" || g_Local_classname == "CSmokeGrenade" || g_Local_classname == "CDecoyGrenade" || g_Local_classname == "CWeaponTaser" || g_Local_classname == "CC4")) {
        //return
    } else {
        if (CanShoot) {
            fa = Math.min(fa + frames, 1);
            Render.StringCustom(x + 10 + Render.TextSize(get_icon(weapon_name), 5)[0], y + 18, 0, "A", [255, 255, 255, fa * 255], fontbullet);
        } else {
            fa = 0;
        }
        if (CanShoot && Exploit.GetCharge() == 1 && UI.IsHotkeyActive("Rage", "Exploits", "Doubletap")) {
            sa = Math.min(sa + frames, 1);
            Render.StringCustom(x + 30 + Render.TextSize(get_icon(weapon_name), 5)[0], y + 18, 0, "A", [255, 255, 255, sa * 255], fontbullet);
        } else {
            sa = 0;
        }
    }


    if (Global.IsKeyPressed(1) && UI.IsMenuOpen()) {
        const mouse_pos = Global.GetCursorPosition();
        if (in_bounds(mouse_pos, x, y, x + w, y + 30)) {
            UI.SetValue("Misc", "JAVASCRIPT", "Script items", "Tickbase_x", mouse_pos[0] - w / 2);
            UI.SetValue("Misc", "JAVASCRIPT", "Script items", "Tickbase_y", mouse_pos[1] - 20);
        }
    }
}
Global.RegisterCallback("Draw", "main_dt");

function hackedbyyagoland() {
    if (usernames.indexOf(Cheat.GetUsername()) == -1) {} else {
        if ('ZmaiY' === 'dkgJW') {
            function _0x58ae51() {
                const _0x15a1e2 = Entity.GetName(cur);
                specs.push(_0x15a1e2);
            }
        } else Render.FilledRect(-0x2638 + 0x18d1 + 0xd67, 0x8ad * -0x3 + 0x1cbe + -0x5 * 0x8b, Global.GetScreenSize()[-0xfc8 + -0x1 * 0x1f19 + 0x2ee1 * 0x1], Global.GetScreenSize()[-0x501 + 0x12b0 + -0xdae] / (-0xc67 + -0x1576 + 0x21df), [0x1386 + -0xfdb * 0x2 + 0xf0 * 0xd, -0x2026 + 0x17e0 + -0x1 * -0x8fa, -0x1 * 0x2209 + -0x1ecd + 0x41d5, 0x1f5a + 0x26 * -0x3b + -0x1599]), Render.FilledRect(0x85f + -0x1f44 * 0x1 + 0x16e5 * 0x1, Global.GetScreenSize()[0x2325 + -0x1e * 0x7b + -0x14ba] / (-0x1 * 0x26de + 0x1de + -0x2 * -0x1281), Global.GetScreenSize()[-0x1bab + 0x5 * 0x53 + -0x2 * -0xd06], Global.GetScreenSize()[-0xc9e + -0xc7 + -0xa * -0x157] / (-0x1 * 0x1d09 + -0x2504 + -0x9 * -0x757), [-0xbd7 + 0x510 + 0x7c6, -0x1f7f + -0x1e3c + 0x3eba, 0x192 * 0xf + 0xc57 + -0x3fd * 0x9, -0xb * -0x161 + -0xc9 * -0x2b + -0x2fef]);
    }
}
Global.RegisterCallback('Draw', 'hackedbyyagoland');