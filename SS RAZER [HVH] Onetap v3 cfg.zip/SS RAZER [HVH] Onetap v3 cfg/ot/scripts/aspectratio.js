var old_aspectratio = Convar.GetString("r_aspectratio");

UI.AddSubTab(["SUBTAB_MGR"], "Aspect Ratio");
UI.AddSliderFloat(["Aspect Ratio", "Aspect Ratio"], "Aspect ratio", 0.0, 5.0);

function aspectratio() {

    var value = UI.GetValue(["Aspect Ratio", "Aspect ratio"]).toString();
    var current = Convar.GetString("r_aspectratio");

    if(current == value) return;
    Convar.SetString("r_aspectratio", value);

}

function restoreAspectRatio() {
    Convar.SetString("r_aspectratio", old_aspectratio);
}

Cheat.RegisterCallback("Unload", "restoreAspectRatio");
Cheat.RegisterCallback("FrameStageNotify", "aspectratio");