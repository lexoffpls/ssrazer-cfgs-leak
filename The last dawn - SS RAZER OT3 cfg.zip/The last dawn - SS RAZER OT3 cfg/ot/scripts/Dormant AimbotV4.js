UI.AddHotkey(["Rage", "General", "General", "Key assignment"], "Dormant Aimbot", "Dormant Aimbot")

function dtr(degress) {
    return degress * Math.PI / 180.0;
}
function rtd(radians) {
    return radians * 180 / Math.PI
}
function deg(vec1, vec2) {
    x = vec2[0] - vec1[0]
    z = vec2[1] - vec1[1]
    y = vec1[2] - vec2[2]
    return [rtd(Math.atan2(z, x)), rtd(Math.atan2(y, Math.sqrt(x * x + z * z)))]
}
function dormant_aim() {
    enemies = Entity.GetEnemies();
    for (i = 0; i < enemies.length; i++) {
        if (Entity.IsAlive(enemies[i]) && Entity.IsDormant(enemies[i])) {
            var startPos = Entity.GetHitboxPosition(Entity.GetLocalPlayer(), 0)
            var endPos = Entity.GetRenderOrigin(enemies[i])
            endPos[2] = endPos[2] + 38
            var trace_result = Trace.Bullet(Entity.GetLocalPlayer(), enemies[i], startPos, endPos);
            if(trace_result[1] > 0) {
                var arr = deg(startPos, endPos);
                var yaw = arr[0]
                var pitch = arr[1]
                if(Local.GetInaccuracy() < 0.01) {
                    UserCMD.SetViewAngles([pitch, yaw, 0], true)
                    UserCMD.SetButtons(UserCMD.GetButtons | 1)
                }
            }
        }
    }
}

Cheat.RegisterCallback("CreateMove", "dormant_aim");
