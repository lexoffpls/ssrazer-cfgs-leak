UI.AddSubTab( ["Misc.", "SUBTAB_MGR"], "Team based")
UI.AddCheckbox( ["Misc.", "Team based", "SHEET_MGR", "Team based"], "Team based knife")
UI.AddDropdown( ["Misc.", "Team based", "SHEET_MGR", "Team based"], "CT Knife", ["None", "Bayonet", "Flip knife", "Gut knife", "Karambit", "M9 bayonet", "Butterfly", "Falchion", "Navaja", "Shadow daggers", "Stiletto", "Bowie", "Huntsman", "Talon", "Ursus", "Classic", "Paracord", "Survival", "Nomad", "Skeleton"], 0)
UI.AddDropdown( ["Misc.", "Team based", "SHEET_MGR", "Team based"], "T Knife", ["None", "Bayonet", "Flip knife", "Gut knife", "Karambit", "M9 bayonet", "Butterfly", "Falchion", "Navaja", "Shadow daggers", "Stiletto", "Bowie", "Huntsman", "Talon", "Ursus", "Classic", "Paracord", "Survival", "Nomad", "Skeleton"], 0)
UI.AddCheckbox( ["Misc.", "Team based", "SHEET_MGR", "Team based"], "Team based model")
UI.AddDropdown( ["Misc.", "Team based", "SHEET_MGR", "Team based"], "CT Model", ["None", "'TwoTimes' McCoy", "Seal Team 6 Soldier", "Buckshot", "Lt. Commander Ricksaw", "Dragomir", "Rezan The Ready", "Maximus", "Blackwolf", "The Doctor' Romanow", "8 Squadron Officer", "3rd Commando Company", "Special Agent Ava", "Operator", "Markus Delrow", "Michael Syfers", "Enforcer", "Slingshot", "Soldier", "The Elite Mr. Muhlik", "Ground Rebel", "Osiris", "Prof. Shahmat", "Cmdr. Mae 'Dead Cold' Jamison", "1st Lieutenant Farlow", "John 'Van Healen' Kask", "Bio-Haz Specialist", "Sergeant Bombson", "Chem-Haz Specialist", "Sir Bloody Miami Darryl", "Sir Bloody Silent Darryl", "Sir Bloody Skullhead Darryl", "Sir Bloody Darryl Royale", "Sir Bloody Loudmouth Darryl", "Safecracker Voltzmann", "Little Kev", "Number K", "Getaway Sally", "Rezan the Redshirt", "'TwoTimes' McCoy Cavalry", "'Blueberries' Buckshot", "Street Soldier", "Footsoldier Dragomir"], 0)
UI.AddDropdown( ["Misc.", "Team based", "SHEET_MGR", "Team based"], "T Model", ["None", "'TwoTimes' McCoy", "Seal Team 6 Soldier", "Buckshot", "Lt. Commander Ricksaw", "Dragomir", "Rezan The Ready", "Maximus", "Blackwolf", "The Doctor' Romanow", "8 Squadron Officer", "3rd Commando Company", "Special Agent Ava", "Operator", "Markus Delrow", "Michael Syfers", "Enforcer", "Slingshot", "Soldier", "The Elite Mr. Muhlik", "Ground Rebel", "Osiris", "Prof. Shahmat", "Cmdr. Mae 'Dead Cold' Jamison", "1st Lieutenant Farlow", "John 'Van Healen' Kask", "Bio-Haz Specialist", "Sergeant Bombson", "Chem-Haz Specialist", "Sir Bloody Miami Darryl", "Sir Bloody Silent Darryl", "Sir Bloody Skullhead Darryl", "Sir Bloody Darryl Royale", "Sir Bloody Loudmouth Darryl", "Safecracker Voltzmann", "Little Kev", "Number K", "Getaway Sally", "Rezan the Redshirt", "'TwoTimes' McCoy Cavalry", "'Blueberries' Buckshot", "Street Soldier", "Footsoldier Dragomir"], 0)

function onFSN(){

    var getknifeT = UI.GetValue( ["Misc.", "Team based", "SHEET_MGR", "Team based", "T Knife"])
    var getknifeCT = UI.GetValue( ["Misc.", "Team based", "SHEET_MGR", "Team based", "CT Knife"])
    var setknifeT;
    var setknifeCT;
    
    switch(getknifeT) {
        case 0: setknifeT = 0; break;
        case 1: setknifeT = 500; break;
        case 2: setknifeT = 505; break;
        case 3: setknifeT = 506; break;
        case 4: setknifeT = 507; break;
        case 5: setknifeT = 508; break;
        case 6: setknifeT = 515; break;
        case 7: setknifeT = 512; break;
        case 8: setknifeT = 520; break;
        case 9: setknifeT = 516; break;
        case 10: setknifeT = 522; break;
        case 11: setknifeT = 514; break;
        case 12: setknifeT = 509; break;
        case 13: setknifeT = 523; break;
        case 14: setknifeT = 519; break;
        case 15: setknifeT = 503; break;
        case 16: setknifeT = 517; break;
        case 17: setknifeT = 518; break;
        case 18: setknifeT = 521; break;
        case 19: setknifeT = 525; break;
    }
    switch(getknifeCT) {
        case 0: setknifeCT = 0; break;
        case 1: setknifeCT = 500; break;
        case 2: setknifeCT = 505; break;
        case 3: setknifeCT = 506; break;
        case 4: setknifeCT = 507; break;
        case 5: setknifeCT = 508; break;
        case 6: setknifeCT = 515; break;
        case 7: setknifeCT = 512; break;
        case 8: setknifeCT = 520; break;
        case 9: setknifeCT = 516; break;
        case 10: setknifeCT = 522; break;
        case 11: setknifeCT = 514; break;
        case 12: setknifeCT = 509; break;
        case 13: setknifeCT = 523; break;
        case 14: setknifeCT = 519; break;
        case 15: setknifeCT = 503; break;
        case 16: setknifeCT = 517; break;
        case 17: setknifeCT = 518; break;
        case 18: setknifeCT = 521; break;
        case 19: setknifeCT = 525; break;
    }

    if(Cheat.FrameStage() != 2)
        return
    var team = Entity.GetProp(Entity.GetLocalPlayer(),"DT_BaseEntity", "m_iTeamNum")

    if(UI.GetValue( ["Misc.", "Team based", "SHEET_MGR", "Team based", "Team based knife"]) == 1) {
        UI.SetEnabled( ["Misc.", "Team based", "SHEET_MGR", "Team based", "CT Knife"], 1)
        UI.SetEnabled( ["Misc.", "Team based", "SHEET_MGR", "Team based", "T Knife"], 1)
        if(team == 2){
            UI.SetValue( ["Misc.", "Skins", "Models", "Knife model"], setknifeT)
        }
        if(team == 3){
            UI.SetValue( ["Misc.", "Skins", "Models", "Knife model"], setknifeCT)
        }
    }
    else{
        UI.SetEnabled( ["Misc.", "Team based", "SHEET_MGR", "Team based", "CT Knife"], 0)
        UI.SetEnabled( ["Misc.", "Team based", "SHEET_MGR", "Team based", "T Knife"], 0)
    }
    if(UI.GetValue( ["Misc.", "Team based", "SHEET_MGR", "Team based", "Team based model"]) == 1){
        UI.SetEnabled( ["Misc.", "Team based", "SHEET_MGR", "Team based", "CT Model"], 1)
        UI.SetEnabled( ["Misc.", "Team based", "SHEET_MGR", "Team based", "T Model"], 1)
        if(team == 2){
            UI.SetValue( ["Misc.", "Skins", "Models", "Player model"], UI.GetValue( ["Misc.", "Team based", "SHEET_MGR", "Team based", "T Model"]))
        }
        if(team == 3){
            UI.SetValue( ["Misc.", "Skins", "Models", "Player model"], UI.GetValue( ["Misc.", "Team based", "SHEET_MGR", "Team based", "CT Model"]))
        }
    }
    else{
        UI.SetEnabled( ["Misc.", "Team based", "SHEET_MGR", "Team based", "CT Model"], 0)
        UI.SetEnabled( ["Misc.", "Team based", "SHEET_MGR", "Team based", "T Model"], 0)
    }
}
Cheat.RegisterCallback("FrameStageNotify","onFSN")

// Team based skin changer