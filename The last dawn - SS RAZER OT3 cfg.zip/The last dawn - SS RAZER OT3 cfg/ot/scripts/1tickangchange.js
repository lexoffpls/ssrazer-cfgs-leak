var flip = false
function functionname() {
    flip = !flip
    if (flip) {

    }
    else{
    }
}
Cheat.RegisterCallback("CreateMove", "functionname")