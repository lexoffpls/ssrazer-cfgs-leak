UI.AddCheckbox(["Visuals", "Extra", "Impacts"], "Lighting on kill");
UI.AddCheckbox(["Visuals", "Extra", "Impacts"], "Thunder sound effect");

function death() {
    var enable = UI.GetValue(["Visuals", "Extra", "Impacts", "Lighting on kill"]);
    var sound_effect = UI.GetValue(["Visuals", "Extra", "Impacts", "Thunder sound effect"]) ? true : false;

    var local = Entity.GetLocalPlayer();
    var attacker = Event.GetInt("attacker");
    var victim = Event.GetInt("userid");
    var attacker_index = Entity.GetEntityFromUserID(attacker);
    var victim_index = Entity.GetEntityFromUserID(victim);
    var pos = Entity.GetRenderOrigin(victim_index);

    if (local != attacker_index || !enable)
        return;

    World.CreateLightningStrike(sound_effect, pos);
}

Cheat.RegisterCallback("player_death", "death")