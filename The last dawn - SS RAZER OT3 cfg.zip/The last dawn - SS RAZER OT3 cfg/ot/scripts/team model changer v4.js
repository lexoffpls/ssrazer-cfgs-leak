UI.AddDropdown(['Misc.', 'Skins', 'Models'], 'CT Model', ['None', "'TwoTimes' McCoy [CT]", 'Seal Team 6 Soldier [CT]', 'Buckshot [CT]', 'Lt. Commander Ricksaw [CT]', 'Dragomir [T]', 'Rezan The Ready [T]', 'Maximus [T]',
'Blackwolf [T]', "The Doctor' Romanov [T]", 'B Squadron Officer [CT]', '3rd Commando Company [CT]', 'Special Agent Ava [CT]', 'Operator [CT]', 'Markus Delrow [CT]', 'Michael Syfers [CT]', 'Enforcer [T]', 
'Slingshot [T]', 'Soldier [T]', 'The Elite Mr. Muhlik [T]', 'Ground Rebel [T]', 'Osiris [T]', 'Prof. Shahmat [T]', "Cmdr. Mae 'Dead Cold' Jamison [CT]", '1st Lieutenant Farlow [CT]', "John 'Van Healen' Kask [CT]",
'Bio-Haz Specialist [CT]', 'Sergeant Bombson [CT]', 'Chem-Haz Specialist [CT]', 'Sir Bloody Miami Darryl [T]', 'Sir Bloody Silent Darryl [T]', 'Sir Bloody Skullhead Darryl [T]', 'Sir Bloody Loudmouth Darryl [T]',
'Safecracker Voltzmann [T]', 'Little Kev [T]', 'Number K [T]', 'Getaway Sally [T]', 'Rezan The Redshirt [T]', "'Two Times' McCoy Cavalry [CT]", "'Blueberries' Buckshot [CT]", 'Street Soldier [T]', 'Footsoldier Dragomir [T]'], 1)
UI.AddDropdown(['Misc.', 'Skins', 'Models'], 'T Model', ['None', "'TwoTimes' McCoy [CT]", 'Seal Team 6 Soldier [CT]', 'Buckshot [CT]', 'Lt. Commander Ricksaw [CT]', 'Dragomir [T]', 'Rezan The Ready [T]', 'Maximus [T]',
'Blackwolf [T]', "The Doctor' Romanov [T]", 'B Squadron Officer [CT]', '3rd Commando Company [CT]', 'Special Agent Ava [CT]', 'Operator [CT]', 'Markus Delrow [CT]', 'Michael Syfers [CT]', 'Enforcer [T]', 
'Slingshot [T]', 'Soldier [T]', 'The Elite Mr. Muhlik [T]', 'Ground Rebel [T]', 'Osiris [T]', 'Prof. Shahmat [T]', "Cmdr. Mae 'Dead Cold' Jamison [CT]", '1st Lieutenant Farlow [CT]', "John 'Van Healen' Kask [CT]",
'Bio-Haz Specialist [CT]', 'Sergeant Bombson [CT]', 'Chem-Haz Specialist [CT]', 'Sir Bloody Miami Darryl [T]', 'Sir Bloody Silent Darryl [T]', 'Sir Bloody Skullhead Darryl [T]', 'Sir Bloody Loudmouth Darryl [T]',
'Safecracker Voltzmann [T]', 'Little Kev [T]', 'Number K [T]', 'Getaway Sally [T]', 'Rezan The Redshirt [T]', "'Two Times' McCoy Cavalry [CT]", "'Blueberries' Buckshot [CT]", 'Street Soldier [T]', 'Footsoldier Dragomir [T]'], 1)
UI.SetEnabled(['Misc.', 'Skins', 'Models', 'Player model'], 0)

function model() {
    team = Entity.GetProp(Entity.GetLocalPlayer(),"DT_BaseEntity", "m_iTeamNum")

    if (team == 2) { UI.SetValue(['Misc.', 'Skins', 'Models', 'Player model'], UI.GetValue(['Misc.', 'Skins', 'Models', 'T Model'])) }

    if (team == 3) { UI.SetValue(['Misc.', 'Skins', 'Models', 'Player model'], UI.GetValue(['Misc.', 'Skins', 'Models', 'CT Model'])) }
}

Cheat.RegisterCallback('Draw', 'model')