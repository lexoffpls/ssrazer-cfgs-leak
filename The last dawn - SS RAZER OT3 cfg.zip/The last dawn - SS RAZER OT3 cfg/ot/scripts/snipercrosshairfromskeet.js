// Skeet Crosshair for OneTap Crack
// Made by cr1pwalk#7306 & Morty#9999 & frisch#4693
// Enjoy

// getscreensize added by enQ
// happy game


UI.AddSliderInt ("Distance from crosshair", 0, 200);
UI.AddSliderInt ("Size of lines", 20, 200);

function d() {
    var dist = UI.GetValue ("Misc", "JAVASCRIPT", "Script items", "Distance from crosshair");
    var size = UI.GetValue ("Misc", "JAVASCRIPT", "Script items", "Size of lines");
    var local = Entity.GetLocalPlayer();
    var is_scope = Entity.GetProp (local, "DT_CSPlayer", "m_bIsScoped");

    if ( is_scope ) {
        var screen_size = Global.GetScreenSize();
            x = screen_size[0] / 2;
            y = screen_size[1] / 2;

        Convar.SetString("cl_drawhud", "0");

        Render.GradientRect ( x + dist, y, size, 1, 1, [ 55, 59,  68,  0 ], [ 66, 134, 244, 255 ] );
        Render.GradientRect ( x, y + dist, 1, size, 0, [ 55, 59,  68,  0 ], [ 66, 134, 244, 255 ] );

        Render.GradientRect ( x - dist - size, y, size, 1, 1, [ 66, 134, 244, 255 ], [ 55, 59,  68,  0 ] );
        Render.GradientRect ( x, y - dist - size, 1, size, 0, [ 66, 134, 244, 255 ], [ 55, 59,  68,  0 ] );
    }
    else {
        Convar.SetString("cl_drawhud", "1");

    }
}

Cheat.RegisterCallback("Draw", "d")