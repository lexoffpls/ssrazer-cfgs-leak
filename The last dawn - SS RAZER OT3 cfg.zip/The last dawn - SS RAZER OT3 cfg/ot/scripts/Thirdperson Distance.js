function ChangeDist()
{
    Dist = UI.GetValue( "Misc", "JAVASCRIPT", "Thirdperson Distance Val");
    UI.SetValue( "Visuals", "WORLD", "View", "Thirdperson", Dist );
}
Cheat.RegisterCallback("FrameStageNotify", "ChangeDist");

function Main()
{
    UI.AddSliderFloat("Thirdperson Distance Val", 50, 300)
}
Main();