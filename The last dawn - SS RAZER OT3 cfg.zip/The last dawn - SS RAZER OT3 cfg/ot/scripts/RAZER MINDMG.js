function isHeavyPistol(name)
{
    if (name == "r8 revolver" || name == "desert eagle")
    {
        return true
    }
}

function isPistol(name)
{
    if (name == "glock 18" || name == "five seven" || name == "dual berettas" || name == "p250" || name == "tec 9" || name == "usp s" || name == "cz75 auto" || name == "p2000")
    {
        return true
    }
}

function isAutoSniper(name)
{
    if(name == "scar 20" || name == "g3sg1")
    {
        return true
    }
}

function indicator()
{
    const y = Render.GetScreenSize()[1];
    wep = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))
    general = UI.GetValue("Rage", "GENERAL", "Targeting", "Minimum damage")
    pistol = UI.GetValue("Rage", "PISTOL", "Targeting", "Minimum damage")
    heavy = UI.GetValue("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage")
    scout = UI.GetValue("Rage", "SCOUT", "Targeting", "Minimum damage")
    awp = UI.GetValue("Rage", "AWP", "Targeting", "Minimum damage")
    auto = UI.GetValue("Rage", "AUTOSNIPER", "Targeting", "Minimum damage")
    font = Render.AddFont("Verdana", 7, 700);

    var str = ""
    if (Entity.IsValid(Entity.GetLocalPlayer()) && Entity.IsAlive(Entity.GetLocalPlayer()))
    {
        if (isPistol(wep))
        {
            str = pistol
        }
        else if (isHeavyPistol(wep))
        {
            str = heavy
        }
        else if(wep == "ssg 08")
        {
            str = scout
        }
        else if(wep == "awp")
        {
            str = awp
        }
        else if (isAutoSniper(wep))
        {
            str = auto
        }
        else
        {
            str = general
        }
    }
         Render.StringCustom(958, y - 584, 0, str+"", [ 0, 0, 0, 100 ], font);
         Render.StringCustom(957, y - 584, 0, str+"", [255, 255, 255, 255], font)
}
Cheat.RegisterCallback("Draw", "indicator");